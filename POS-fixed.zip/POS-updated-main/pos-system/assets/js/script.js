/* ============================================
   POS SYSTEM - GLOBAL JS HELPERS
   Loaded on every page. Provides the small set
   of helper functions the modules call:
   showToast, showSuccess, showError, showInfo,
   confirmAction, confirmDelete, toggleTheme
   ============================================ */

(function () {
    'use strict';

    // --------------------------------------------
    // THEME (dark / light mode)
    // --------------------------------------------
    function applyTheme(theme) {
        document.documentElement.setAttribute('data-bs-theme', theme);
        var icon = document.getElementById('themeIcon');
        if (icon) {
            icon.classList.remove('fa-moon', 'fa-sun');
            icon.classList.add(theme === 'dark' ? 'fa-sun' : 'fa-moon');
        }
    }

    // Apply saved theme as early as possible to avoid a flash of the wrong theme.
    var savedTheme = localStorage.getItem('pos_theme') || 'light';
    applyTheme(savedTheme);

    window.toggleTheme = function () {
        var current = document.documentElement.getAttribute('data-bs-theme') || 'light';
        var next = current === 'dark' ? 'light' : 'dark';
        localStorage.setItem('pos_theme', next);
        applyTheme(next);
    };

    // --------------------------------------------
    // NOTIFICATIONS (SweetAlert2 based)
    // --------------------------------------------
    function hasSwal() {
        return typeof Swal !== 'undefined';
    }

    // Small toast, used for quick, non-blocking feedback (e.g. cart actions).
    // Signature used across the app: showToast(message, type, position)
    window.showToast = function (message, type, position) {
        type = type || 'info';
        position = position || 'top-end';

        if (!hasSwal()) {
            console.log('[' + type + '] ' + message);
            return;
        }

        var Toast = Swal.mixin({
            toast: true,
            position: position,
            showConfirmButton: false,
            timer: 2500,
            timerProgressBar: true,
            didOpen: function (el) {
                el.addEventListener('mouseenter', Swal.stopTimer);
                el.addEventListener('mouseleave', Swal.resumeTimer);
            }
        });

        Toast.fire({
            icon: type === 'error' ? 'error' : (type === 'success' ? 'success' : (type === 'warning' ? 'warning' : 'info')),
            title: message
        });
    };

    // Full-size confirmation alert used for success/error/info messages.
    window.showSuccess = function (message, title) {
        if (!hasSwal()) { alert(message); return; }
        Swal.fire({
            icon: 'success',
            title: title || 'Success!',
            text: message,
            confirmButtonColor: '#198754',
            confirmButtonText: 'OK'
        });
    };

    window.showError = function (message, title) {
        if (!hasSwal()) { alert(message); return; }
        Swal.fire({
            icon: 'error',
            title: title || 'Error',
            text: message,
            confirmButtonColor: '#dc3545',
            confirmButtonText: 'OK'
        });
    };

    window.showInfo = function (message, title) {
        if (!hasSwal()) { alert(message); return; }
        Swal.fire({
            icon: 'info',
            title: title || 'Info',
            text: message,
            confirmButtonColor: '#0d6efd',
            confirmButtonText: 'OK'
        });
    };

    // --------------------------------------------
    // CONFIRMATIONS
    // --------------------------------------------
    // Generic confirm dialog: confirmAction(message, title, onConfirm)
    window.confirmAction = function (message, title, onConfirm) {
        if (!hasSwal()) {
            if (confirm(message)) { onConfirm && onConfirm(); }
            return;
        }
        Swal.fire({
            title: title || 'Please Confirm',
            text: message,
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#0d6efd',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'Yes',
            cancelButtonText: 'Cancel'
        }).then(function (result) {
            if (result.isConfirmed && typeof onConfirm === 'function') {
                onConfirm();
            }
        });
    };

    // Delete-flavoured confirm dialog: confirmDelete(message, onConfirm)
    window.confirmDelete = function (message, onConfirm) {
        if (!hasSwal()) {
            if (confirm(message)) { onConfirm && onConfirm(); }
            return;
        }
        Swal.fire({
            title: 'Are you sure?',
            html: message,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#dc3545',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel'
        }).then(function (result) {
            if (result.isConfirmed && typeof onConfirm === 'function') {
                onConfirm();
            }
        });
    };

    // --------------------------------------------
    // FLASH MESSAGES
    // Many pages render:
    // <div id="flash-message" data-type="success|error" data-message="..."></div>
    // after a form submission. Pick those up and show them once on load.
    // --------------------------------------------
    document.addEventListener('DOMContentLoaded', function () {
        var flashEls = document.querySelectorAll('#flash-message, .flash-message');
        flashEls.forEach(function (el) {
            var type = el.getAttribute('data-type') || 'info';
            var message = el.getAttribute('data-message') || '';
            if (!message) return;

            if (!hasSwal()) {
                console.log('[' + type + '] ' + message);
                return;
            }

            Swal.fire({
                icon: type === 'error' ? 'error' : 'success',
                title: type === 'error' ? 'Oops!' : 'Success!',
                html: message,
                confirmButtonColor: type === 'error' ? '#dc3545' : '#198754',
                confirmButtonText: 'OK',
                timer: type === 'error' ? undefined : 3000,
                timerProgressBar: type !== 'error'
            });
        });
    });
})();
