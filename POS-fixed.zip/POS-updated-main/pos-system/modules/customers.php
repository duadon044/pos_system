<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ' . BASE_PATH . 'login.php');
    exit();
}

if (!hasPermission('view_sales')) {
    logActivity("Access denied: customers.php - User: " . $_SESSION['username']);
    header('Location: ' . BASE_PATH . 'index.php?error=access_denied');
    exit();
}

$db = getDB();

$success_message = null;
$error_message = null;

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_customer'])) {
    $customer_code = sanitize($_POST['customer_code']);
    $first_name = sanitize($_POST['first_name']);
    $last_name = sanitize($_POST['last_name']);
    $email = sanitize($_POST['email']);
    $phone = sanitize($_POST['phone']);
    $address = sanitize($_POST['address']);
    $company = sanitize($_POST['company']);
    $tax_id = sanitize($_POST['tax_id']);
    
    try {
        $stmt = $db->prepare("INSERT INTO customers (customer_code, first_name, last_name, email, phone, address, company, tax_id) 
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$customer_code, $first_name, $last_name, $email, $phone, $address, $company, $tax_id]);
        $success_message = "Customer <strong>{$first_name} {$last_name}</strong> added successfully!";
        logActivity("Added customer: {$first_name} {$last_name}");
    } catch(PDOException $e) {
        $error_message = "Error: " . $e->getMessage();
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_customer'])) {
    $id = (int)$_POST['customer_id'];
    $customer_code = sanitize($_POST['customer_code']);
    $first_name = sanitize($_POST['first_name']);
    $last_name = sanitize($_POST['last_name']);
    $email = sanitize($_POST['email']);
    $phone = sanitize($_POST['phone']);
    $address = sanitize($_POST['address']);
    $company = sanitize($_POST['company']);
    $tax_id = sanitize($_POST['tax_id']);

    try {
        $stmt = $db->prepare("UPDATE customers SET customer_code = ?, first_name = ?, last_name = ?, email = ?, phone = ?, address = ?, company = ?, tax_id = ? WHERE id = ?");
        $stmt->execute([$customer_code, $first_name, $last_name, $email, $phone, $address, $company, $tax_id, $id]);
        $success_message = "Customer <strong>{$first_name} {$last_name}</strong> updated successfully!";
        logActivity("Updated customer: {$first_name} {$last_name}");
    } catch(PDOException $e) {
        $error_message = "Error: " . $e->getMessage();
    }
}

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    try {
        $db->prepare("DELETE FROM customers WHERE id = ?")->execute([$id]);
        echo json_encode(['success' => true, 'message' => 'Customer deleted successfully!']);
    } catch(Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit();
}

$customers = $db->query("SELECT * FROM customers ORDER BY created_at DESC")->fetchAll();

$stats = [
    'total' => $db->query("SELECT COUNT(*) FROM customers")->fetchColumn(),
    'with_company' => $db->query("SELECT COUNT(*) FROM customers WHERE company IS NOT NULL AND company != ''")->fetchColumn(),
];
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo BASE_PATH; ?>assets/css/custom.css">
</head>
<body>
    <?php include BASE_PATH . 'includes/header.php'; ?>
    
    <div class="d-flex">
        <?php include BASE_PATH . 'includes/sidebar.php'; ?>
        
        <div class="main-content flex-grow-1 p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h4 class="mb-0"><i class="fas fa-users me-2 text-primary"></i> Customer Management</h4>
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addCustomerModal">
                    <i class="fas fa-plus-circle me-1"></i> Add Customer
                </button>
            </div>
            
            <?php if (isset($success_message)): ?>
                <div id="flash-message" data-type="success" data-message="<?php echo htmlspecialchars($success_message); ?>"></div>
            <?php endif; ?>
            <?php if (isset($error_message)): ?>
                <div id="flash-message" data-type="error" data-message="<?php echo htmlspecialchars($error_message); ?>"></div>
            <?php endif; ?>
            
            <div class="row g-3 mb-4">
                <div class="col-md-6">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h6 class="text-muted">Total Customers</h6>
                            <h3 class="fw-bold text-primary"><?php echo $stats['total']; ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h6 class="text-muted">With Company</h6>
                            <h3 class="fw-bold text-info"><?php echo $stats['with_company']; ?></h3>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card border-0 shadow-sm">
                <div class="card-body table-responsive">
                    <table class="table table-hover" id="customerTable">
                        <thead>
                            <tr>
                                <th>Code</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Company</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($customers as $c): ?>
                            <tr id="customer-row-<?php echo $c['id']; ?>">
                                <td><span class="badge bg-secondary"><?php echo $c['customer_code']; ?></span></td>
                                <td><strong><?php echo $c['first_name'] . ' ' . $c['last_name']; ?></strong></td>
                                <td><?php echo $c['email']; ?></td>
                                <td><?php echo $c['phone']; ?></td>
                                <td><?php echo $c['company'] ?: '-'; ?></td>
                                <td>
                                    <button class="btn btn-sm btn-info edit-customer"
                                            data-id="<?php echo $c['id']; ?>"
                                            data-code="<?php echo htmlspecialchars($c['customer_code']); ?>"
                                            data-first="<?php echo htmlspecialchars($c['first_name']); ?>"
                                            data-last="<?php echo htmlspecialchars($c['last_name']); ?>"
                                            data-email="<?php echo htmlspecialchars($c['email']); ?>"
                                            data-phone="<?php echo htmlspecialchars($c['phone']); ?>"
                                            data-address="<?php echo htmlspecialchars($c['address']); ?>"
                                            data-company="<?php echo htmlspecialchars($c['company']); ?>"
                                            data-tax="<?php echo htmlspecialchars($c['tax_id']); ?>">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-danger delete-customer" data-id="<?php echo $c['id']; ?>" data-name="<?php echo $c['first_name'] . ' ' . $c['last_name']; ?>">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                    <a href="<?php echo BASE_PATH; ?>modules/sales.php?customer=<?php echo $c['id']; ?>" class="btn btn-sm btn-success">
                                        <i class="fas fa-cash-register"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="addCustomerModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-user-plus me-2 text-primary"></i> Add Customer</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Customer Code</label>
                                <input type="text" name="customer_code" class="form-control" required placeholder="CUST-001">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Company</label>
                                <input type="text" name="company" class="form-control" placeholder="Company name (optional)">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">First Name</label>
                                <input type="text" name="first_name" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Last Name</label>
                                <input type="text" name="last_name" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Phone</label>
                                <input type="text" name="phone" class="form-control">
                            </div>
                            <div class="col-12">
                                <label class="form-label">Address</label>
                                <textarea name="address" class="form-control" rows="2"></textarea>
                            </div>
                            <div class="col-md-12">
                                <label class="form-label">Tax ID (TIN)</label>
                                <input type="text" name="tax_id" class="form-control" placeholder="Optional">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="add_customer" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i> Save Customer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Customer Modal -->
    <div class="modal fade" id="editCustomerModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-user-edit me-2 text-info"></i> Edit Customer</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <input type="hidden" name="customer_id" id="edit_customer_id">
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Customer Code</label>
                                <input type="text" name="customer_code" id="edit_customer_code" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Company</label>
                                <input type="text" name="company" id="edit_company" class="form-control">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">First Name</label>
                                <input type="text" name="first_name" id="edit_first_name" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Last Name</label>
                                <input type="text" name="last_name" id="edit_last_name" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" id="edit_email" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Phone</label>
                                <input type="text" name="phone" id="edit_phone" class="form-control">
                            </div>
                            <div class="col-12">
                                <label class="form-label">Address</label>
                                <textarea name="address" id="edit_address" class="form-control" rows="2"></textarea>
                            </div>
                            <div class="col-md-12">
                                <label class="form-label">Tax ID (TIN)</label>
                                <input type="text" name="tax_id" id="edit_tax_id" class="form-control">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="edit_customer" class="btn btn-info">
                            <i class="fas fa-save me-1"></i> Save Changes
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo BASE_PATH; ?>assets/js/script.js"></script>
    
    <script>
        document.querySelectorAll('.edit-customer').forEach(function(button) {
            button.addEventListener('click', function() {
                document.getElementById('edit_customer_id').value = this.dataset.id;
                document.getElementById('edit_customer_code').value = this.dataset.code;
                document.getElementById('edit_first_name').value = this.dataset.first;
                document.getElementById('edit_last_name').value = this.dataset.last;
                document.getElementById('edit_email').value = this.dataset.email;
                document.getElementById('edit_phone').value = this.dataset.phone;
                document.getElementById('edit_address').value = this.dataset.address;
                document.getElementById('edit_company').value = this.dataset.company;
                document.getElementById('edit_tax_id').value = this.dataset.tax;
                new bootstrap.Modal(document.getElementById('editCustomerModal')).show();
            });
        });

        document.querySelectorAll('.delete-customer').forEach(btn => {
            btn.addEventListener('click', function() {
                const id = this.dataset.id;
                const name = this.dataset.name;
                
                confirmDelete(`Customer "${name}" will be permanently deleted!`, function() {
                    Swal.fire({
                        title: 'Deleting...',
                        text: 'Please wait',
                        allowOutsideClick: false,
                        showConfirmButton: false,
                        didOpen: () => Swal.showLoading()
                    });
                    
                    fetch(`?delete=${id}`)
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                showSuccess(data.message);
                                document.getElementById(`customer-row-${id}`).remove();
                            } else {
                                showError(data.message);
                            }
                        })
                        .catch(() => showError('Error deleting customer!'));
                });
            });
        });
    </script>
</body>
</html>