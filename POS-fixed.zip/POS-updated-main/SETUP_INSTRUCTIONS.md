# POS System — Setup Instructions

This is a PHP + MySQL point-of-sale / procurement / HRM system. It needs a
local PHP + MySQL server (e.g. **XAMPP**, **WAMP**, or **Laragon**) — it
can't run inside a browser on its own.

## What was fixed in this version

- Added the missing `assets/js/script.js` and `assets/css/custom.css` files
  that every page depends on (toasts, delete confirmations, success/error
  messages, dark mode toggle). Without these, most buttons across the app
  silently did nothing.
- Fixed the "Edit" buttons on the Products and Customers pages (they had no
  handler at all before).
- Rewrote the Database Backup feature to generate backups in pure PHP
  instead of shelling out to `mysqldump` (which needs to be on the server's
  PATH and was failing silently before — the sample backup file in the
  original zip literally contained a Windows error message instead of SQL).
- Fixed a SQL-injection / reflected-XSS spot in the Reports date filter.
- Fixed the "Clear Logs" button in Activity Logs (no backend handler
  existed for it).
- Added a missing permission check on the Requisitions page (it was the
  only page in the app anyone logged-in could reach regardless of role).
- Minor polish (print receipt page missing Bootstrap CSS, dashboard
  widgets endpoint not returning JSON).

## 1. Install a local server stack

Download and install one of:
- **XAMPP** — https://www.apachefriends.org/
- **Laragon** (Windows, lighter weight) — https://laragon.org/
- **WAMP** (Windows) — https://www.wampserver.com/

Start **Apache** and **MySQL** from the control panel.

## 2. Copy the project files

Copy the `pos-system` folder into your server's web root:
- XAMPP: `C:\xampp\htdocs\pos-system` (or `/opt/lampp/htdocs/pos-system` on Linux)
- Laragon: `C:\laragon\www\pos-system`
- WAMP: `C:\wamp64\www\pos-system`

## 3. Create the database

1. Open **phpMyAdmin** (usually `http://localhost/phpmyadmin`).
2. Click **New**, create a database named exactly `pos_system`.
3. Select it, click the **Import** tab, choose the `pos_system.sql` file
   from this zip, and click **Go**.

If your MySQL root user has a password, or you're not using `root`/no
password, update `pos-system/config/database.php`:

```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');        // <-- set your password here
define('DB_NAME', 'pos_system');
```

## 4. Open the app

Visit `http://localhost/pos-system/login.php` in your browser.

Default login:
- **Username:** `admin`
- **Password:** `admin123`

(If no `admin` user exists yet, `login.php` will create one automatically
on first load using these credentials.)

## 5. Notes

- The **Backup** module (Admin → Backup & Restore) writes `.sql` files into
  `pos-system/backups/` — make sure that folder is writable by the web
  server (it should be by default on XAMPP/Laragon/WAMP).
- The app is built with Bootstrap 5, Font Awesome, SweetAlert2, and Chart.js,
  all loaded from CDNs — an internet connection is needed for the pages to
  look and behave correctly.
- Roles seeded by default: Admin, HRM, Cashier, Inventory, Finance. You can
  manage roles and permissions from Administration → Roles & Permissions.
