<?php
if(session_status()!==PHP_SESSION_ACTIVE)session_start();
const MAX_PRICE=9999999.99; const MAX_QTY=1000000; const MAX_PERCENT=100;
function csrf_token():string{if(empty($_SESSION['csrf_token']))$_SESSION['csrf_token']=bin2hex(random_bytes(32));return $_SESSION['csrf_token'];}
function csrf_field():string{return '<input type="hidden" name="csrf_token" value="'.htmlspecialchars(csrf_token(),ENT_QUOTES,'UTF-8').'">';}
function verify_csrf():void{
    if($_SERVER['REQUEST_METHOD']!=='POST')return;
    $t=$_POST['csrf_token']??'';
    if(hash_equals($_SESSION['csrf_token']??'',$t))return;
    http_response_code(403);
    // Most "random" token errors are really an expired/idle session (the page was
    // left open past the session timeout). Send the person back to login with a
    // clear message instead of a dead-end blank page.
    if (!isset($_SESSION['user_id'])) {
        header('Location: ' . (defined('BASE_PATH') ? BASE_PATH : '/') . 'login.php?error=' . urlencode('Your session has expired. Please log in again.'));
        exit();
    }
    $isAjax = (strtolower($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'xmlhttprequest')
        || (strpos($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') !== false);
    if ($isAjax) {
        header('Content-Type: application/json');
        echo json_encode(['ok' => false, 'error' => 'Your session has expired. Please refresh the page and try again.']);
        exit();
    }
    exit('Your security token has expired. Please go back, refresh the page, and try again.');
}
function valid_money($v,bool $zero=true):bool{if(!is_numeric($v))return false;$n=(float)$v;return is_finite($n)&&($zero?$n>=0:$n>0)&&$n<=MAX_PRICE&&round($n,2)==$n;}
function valid_qty($v,bool $zero=false):bool{if(filter_var($v,FILTER_VALIDATE_INT)===false)return false;$n=(int)$v;return ($zero?$n>=0:$n>0)&&$n<=MAX_QTY;}
function valid_percent($v):bool{return is_numeric($v)&&(float)$v>=0&&(float)$v<=MAX_PERCENT;}
function require_permission(string $p):void{if(!isset($_SESSION['user_id'])){header('Location: '.BASE_PATH.'login.php');exit();}if((int)($_SESSION['role_id']??0)===1||hasPermission($p))return;logActivity('Access denied: '.$p);header('Location: '.BASE_PATH.'index.php?error=access_denied');exit();}
function h($v):string{return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
