<?php
// ============================================
// DATABASE CONFIGURATION
// ============================================
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'pos_system');

// ============================================
// BASE PATH CONFIGURATION - AUTO DETECT
// ============================================
$base_path = '';
$script_name = $_SERVER['SCRIPT_NAME'];

if (strpos($script_name, '/modules/procurement/') !== false) {
    $base_path = '../../';
} elseif (strpos($script_name, '/modules/hrm/') !== false) {
    $base_path = '../../';
} elseif (strpos($script_name, '/modules/inventory/') !== false) {
    $base_path = '../../';
} elseif (strpos($script_name, '/modules/') !== false) {
    $base_path = '../';
} else {
    $base_path = '';
}

define('BASE_PATH', $base_path);
define('BASE_URL', '/pos-system/');

// ============================================
// DATABASE FUNCTIONS
// ============================================
function getDB() {
    try {
        $conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4", DB_USER, DB_PASS, [PDO::ATTR_EMULATE_PREPARES=>false]);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch(PDOException $e) {
        die("Connection failed: " . $e->getMessage());
    }
}

function sanitize($input) {
    return htmlspecialchars(strip_tags(trim($input)));
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function hasPermission($permission) {
    if ((int)($_SESSION['role_id'] ?? 0) === 1 || (($_SESSION['role'] ?? '') === 'Admin')) return true;
    return isset($_SESSION['permissions']) && is_array($_SESSION['permissions']) && in_array($permission, $_SESSION['permissions'], true);
}

// ============================================
// JOB POSTINGS / APPLICATIONS - self-healing tables + permissions
// Makes the careers feature work even if the SQL migration was never run.
// ============================================
function ensure_job_tables(PDO $db): void {
    static $checked = false;
    if ($checked) return;
    $checked = true;
    try {
        $db->exec("CREATE TABLE IF NOT EXISTS job_postings(
            id INT NOT NULL AUTO_INCREMENT,
            title VARCHAR(150) NOT NULL,
            department VARCHAR(100) NULL,
            employment_type VARCHAR(50) NOT NULL DEFAULT 'Full-time',
            location VARCHAR(150) NULL,
            description TEXT NULL,
            requirements TEXT NULL,
            status ENUM('draft','published','closed') NOT NULL DEFAULT 'draft',
            created_by INT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY(id), KEY status(status), KEY created_by(created_by)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->exec("CREATE TABLE IF NOT EXISTS job_applications(
            id INT NOT NULL AUTO_INCREMENT,
            job_id INT NOT NULL,
            applicant_name VARCHAR(150) NOT NULL,
            email VARCHAR(150) NOT NULL,
            phone VARCHAR(30) NULL,
            cover_letter TEXT NULL,
            resume_path VARCHAR(255) NOT NULL,
            status ENUM('pending','shortlisted','interview','rejected','hired') NOT NULL DEFAULT 'pending',
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY(id), KEY job_id(job_id), KEY status(status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $db->exec("INSERT IGNORE INTO permissions(permission_name,module,description) VALUES
            ('manage_job_postings','hrm','Create and manage job postings'),
            ('view_job_applications','hrm','View job applications')");
        $db->exec("INSERT IGNORE INTO role_permissions(role_id,permission_id)
            SELECT r.id,p.id FROM roles r JOIN permissions p
            WHERE r.role_name IN ('Admin','HRM') AND p.permission_name IN ('manage_job_postings','view_job_applications')");
    } catch (Throwable $e) {
        error_log('ensure_job_tables error: ' . $e->getMessage());
    }
}

// Published job postings for the public login/careers pages (never fatal).
function get_published_jobs(PDO $db, int $limit = 0): array {
    try {
        ensure_job_tables($db);
        $sql = "SELECT id,title,department,employment_type,location FROM job_postings WHERE status='published' ORDER BY created_at DESC";
        if ($limit > 0) $sql .= " LIMIT " . (int)$limit;
        return $db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        error_log('get_published_jobs error: ' . $e->getMessage());
        return [];
    }
}

function hasRole($role_name) {
    if (!isset($_SESSION['role'])) return false;
    return $_SESSION['role'] === $role_name;
}

function logActivity($action) {
    if (!isset($_SESSION['user_id'])) return;
    
    $db = getDB();
    $user_id = $_SESSION['user_id'];
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    
    try {
        $stmt = $db->prepare("INSERT INTO activity_logs (user_id, action, ip_address) VALUES (?, ?, ?)");
        $stmt->execute([$user_id, $action, $ip]);
    } catch(Exception $e) {
        // Silent fail for logs
    }
}

function redirect($path) {
    header('Location: ' . BASE_PATH . $path);
    exit();
}

// ============================================
// PRODUCT IMAGE COLUMN (auto-migration)
// Adds products.image the first time a page needs it, so the app keeps
// working even if the SQL migration has not been imported yet.
// ============================================
function ensure_product_image_column(PDO $db): void {
    static $checked = false;
    if ($checked) return;
    $checked = true;
    try {
        $has = $db->query("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'products' AND COLUMN_NAME = 'image'")->fetchColumn();
        if (!(int)$has) {
            $db->exec("ALTER TABLE products ADD COLUMN image VARCHAR(255) NULL DEFAULT NULL AFTER description");
        }
    } catch (Throwable $e) {
        error_log('ensure_product_image_column error: ' . $e->getMessage());
    }
}

// Public URL path for a product image, falling back to the generic placeholder.
function product_image_url(?string $image): string {
    $image = trim((string)$image);
    if ($image === '' || strpos($image, '..') !== false || !preg_match('#^assets/img/products/[A-Za-z0-9._-]+$#', $image)) {
        $image = 'assets/img/products/placeholder.svg';
    }
    return BASE_PATH . $image;
}

// Saves an uploaded product photo (JPG / PNG / WEBP / GIF, max 4 MB) into
// assets/img/products/ and returns the relative path to store in products.image.
// Throws an Exception with a user-friendly message on any problem.
function save_product_image(array $file): string {
    $err = $file['error'] ?? UPLOAD_ERR_NO_FILE;
    if ($err !== UPLOAD_ERR_OK) {
        $msgs = [
            UPLOAD_ERR_INI_SIZE   => 'The photo is larger than the server allows (upload_max_filesize).',
            UPLOAD_ERR_FORM_SIZE  => 'The photo is too large.',
            UPLOAD_ERR_PARTIAL    => 'The photo was only partly uploaded. Please try again.',
            UPLOAD_ERR_NO_FILE    => 'No photo was selected.',
            UPLOAD_ERR_NO_TMP_DIR => 'Server error: missing temporary upload folder.',
            UPLOAD_ERR_CANT_WRITE => 'Server error: unable to write the photo to disk.',
        ];
        throw new Exception($msgs[$err] ?? 'Photo upload failed.');
    }
    if (($file['size'] ?? 0) > 4 * 1024 * 1024) throw new Exception('Photo must be 4 MB or smaller.');
    if (!is_uploaded_file($file['tmp_name'])) throw new Exception('Invalid upload.');

    // Detect the real type from the file contents, never from the file name.
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
    if (!isset($allowed[$mime]) || @getimagesize($file['tmp_name']) === false) {
        throw new Exception('Photo must be a JPG, PNG, WEBP or GIF image.');
    }

    $dir = dirname(__DIR__) . '/assets/img/products';
    if (!is_dir($dir) && !@mkdir($dir, 0755, true)) throw new Exception('Server error: cannot create the photo folder.');
    $name = 'prod_' . bin2hex(random_bytes(8)) . '.' . $allowed[$mime];
    if (!@move_uploaded_file($file['tmp_name'], $dir . '/' . $name)) {
        throw new Exception('Server error: cannot save the photo. Check that assets/img/products is writable.');
    }
    @chmod($dir . '/' . $name, 0644);
    return 'assets/img/products/' . $name;
}

// Deletes a previously uploaded photo. Only files created by save_product_image()
// (prod_*) are removed, so the bundled sample images are never touched.
function delete_product_image(?string $image): void {
    $image = trim((string)$image);
    if (preg_match('#^assets/img/products/(prod_[A-Za-z0-9]+\.(jpg|png|webp|gif))$#', $image, $m)) {
        @unlink(dirname(__DIR__) . '/assets/img/products/' . $m[1]);
    }
}

// ============================================
// INTERNAL NOTIFICATION CENTER (bell icon)
// Dual channel: this writes the in-app notification; callers that also want
// an email should additionally call send_hr_email() (config/mail.php).
// ============================================
function ensure_notifications_table(PDO $db) {
    static $checked = false;
    if ($checked) return;
    $db->exec("CREATE TABLE IF NOT EXISTS notifications(
        id INT NOT NULL AUTO_INCREMENT,
        user_id INT NOT NULL,
        title VARCHAR(150) NOT NULL,
        message VARCHAR(500) NOT NULL,
        link VARCHAR(255) NULL,
        is_read TINYINT(1) NOT NULL DEFAULT 0,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY(id), KEY user_id(user_id), KEY is_read(is_read)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $checked = true;
}

function notify_user(int $userId, string $title, string $message, ?string $link = null): void {
    if ($userId <= 0) return;
    try {
        $db = getDB();
        ensure_notifications_table($db);
        $db->prepare("INSERT INTO notifications(user_id,title,message,link) VALUES(?,?,?,?)")
           ->execute([$userId, $title, $message, $link]);
    } catch (Throwable $e) {
        error_log('notify_user error: ' . $e->getMessage());
    }
}

// Notify every active user who holds the given role name.
function notify_role(string $roleName, string $title, string $message, ?string $link = null): void {
    try {
        $db = getDB();
        ensure_notifications_table($db);
        $users = $db->prepare("SELECT u.id FROM users u JOIN roles r ON r.id=u.role_id WHERE r.role_name=? AND u.is_active=1");
        $users->execute([$roleName]);
        $stmt = $db->prepare("INSERT INTO notifications(user_id,title,message,link) VALUES(?,?,?,?)");
        foreach ($users->fetchAll(PDO::FETCH_COLUMN) as $uid) {
            $stmt->execute([$uid, $title, $message, $link]);
        }
    } catch (Throwable $e) {
        error_log('notify_role error: ' . $e->getMessage());
    }
}

// Call right after a stock-decreasing event (sale, approved stock-out). Only
// fires once per crossing (previous qty above threshold, new qty at/below),
// so routine sales on an already-low item don't spam the bell/inbox.
function check_low_stock_alert(PDO $db, int $productId, int $previousQty): void {
    try {
        $p = $db->prepare("SELECT product_name, product_code, stock_quantity, low_stock_threshold FROM products WHERE id=?");
        $p->execute([$productId]);
        $product = $p->fetch();
        if (!$product) return;
        $threshold = (int)($product['low_stock_threshold'] ?? 5);
        $newQty = (int)$product['stock_quantity'];
        if ($previousQty > $threshold && $newQty <= $threshold) {
            $level = $newQty <= 0 ? 'Out of Stock' : 'Low Stock';
            $msg = $product['product_name'] . ' (' . $product['product_code'] . ') is now at ' . $newQty . ' units (threshold: ' . $threshold . ').';
            notify_role('Inventory', $level . ' Alert', $msg, BASE_PATH . 'modules/inventory/stock_movement.php');
            notify_role('Admin', $level . ' Alert', $msg, BASE_PATH . 'modules/inventory/stock_movement.php');
            if (function_exists('send_hr_email')) {
                $recipients = $db->query("SELECT u.email,u.full_name FROM users u JOIN roles r ON r.id=u.role_id WHERE r.role_name IN ('Inventory','Admin') AND u.is_active=1")->fetchAll();
                foreach ($recipients as $r) {
                    if (filter_var($r['email'] ?? '', FILTER_VALIDATE_EMAIL)) {
                        send_hr_email($r['email'], 'POS System: ' . $level . ' - ' . $product['product_name'], '<h2>' . h($level) . ' Alert</h2><p>' . h($msg) . '</p>');
                    }
                }
            }
        }
    } catch (Throwable $e) {
        error_log('check_low_stock_alert error: ' . $e->getMessage());
    }
}

require_once __DIR__.'/security.php';
