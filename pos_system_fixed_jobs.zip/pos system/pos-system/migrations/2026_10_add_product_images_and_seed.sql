-- ============================================================
-- Product images + starter catalog (15 pcs each)
-- Safe to run more than once (idempotent). Run in phpMyAdmin
-- against the `pos_system` database, or let the app add the
-- `image` column automatically (see ensure_product_image_column()).
-- ============================================================

-- 1) image column (skip if it already exists)
SET @col := (SELECT COUNT(*) FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'products' AND COLUMN_NAME = 'image');
SET @ddl := IF(@col = 0, 'ALTER TABLE `products` ADD COLUMN `image` varchar(255) DEFAULT NULL AFTER `description`', 'SELECT 1');
PREPARE s FROM @ddl; EXECUTE s; DEALLOCATE PREPARE s;

-- 2) products: new rows start with 15 pcs; existing rows only get image/description refreshed
INSERT INTO `products`
  (`product_code`,`product_name`,`description`,`image`,`price`,`cost`,`stock_quantity`,`category`,`low_stock_threshold`)
VALUES
('CPU-R5-5600','AMD Ryzen 5 5600 Processor','6-core, 12-thread desktop processor for the AM4 socket. 3.5 GHz base / up to 4.4 GHz boost, 65W TDP, 32MB L3 cache. Includes the Wraith Stealth cooler. Great value for gaming and everyday multitasking.','assets/img/products/CPU-R5-5600.svg',8495.00,7200.00,15,'Computer Parts',5),
('CPU-I5-12400F','Intel Core i5-12400F Processor','6-core, 12-thread 12th Gen processor for the LGA1700 socket. Up to 4.4 GHz turbo, 18MB cache, 65W base power. No integrated graphics, so a discrete graphics card is required. Cooler included.','assets/img/products/CPU-I5-12400F.svg',7995.00,6800.00,15,'Computer Parts',5),
('GPU-RTX3060','NVIDIA GeForce RTX 3060 12GB Graphics Card','12GB GDDR6 graphics card with a 192-bit memory bus and dual-fan cooling. Supports ray tracing and DLSS. Smooth 1080p and capable 1440p gaming, plus GPU acceleration for video editing.','assets/img/products/GPU-RTX3060.svg',17995.00,15500.00,15,'Computer Parts',5),
('MB-B550M','B550M AM4 Micro-ATX Motherboard','Micro-ATX board for AMD Ryzen AM4 processors. 4x DDR4 slots (up to 128GB), PCIe 4.0 x16, M.2 NVMe slot, 4x SATA III, HDMI/DisplayPort outputs, Gigabit LAN and USB 3.2 ports.','assets/img/products/MB-B550M.svg',5995.00,5000.00,15,'Computer Parts',5),
('RAM-16GB-D4','16GB (2x8GB) DDR4 3200MHz Desktop Memory Kit','Dual-channel DDR4-3200 memory kit, 2 x 8GB, CL16, 1.35V, with aluminum heat spreaders. Plug-and-play and compatible with Intel and AMD desktop platforms.','assets/img/products/RAM-16GB-D4.svg',2295.00,1800.00,15,'Computer Parts',5),
('SSD-NVME-512','512GB NVMe M.2 SSD','PCIe NVMe M.2 2280 solid state drive with up to 3,000 MB/s read speed. Cuts boot and load times dramatically and is shock-resistant and silent. 512GB capacity for the OS, apps and games.','assets/img/products/SSD-NVME-512.svg',2495.00,2000.00,15,'Computer Parts',5),
('HDD-1TB-7200','1TB 7200RPM 3.5" SATA Hard Drive','1TB internal desktop hard drive, 7200 RPM, 64MB cache, SATA 6Gb/s. Reliable bulk storage for documents, media and backups.','assets/img/products/HDD-1TB-7200.svg',2195.00,1750.00,15,'Computer Parts',5),
('PSU-650W-BZ','650W 80+ Bronze Power Supply','650W ATX power supply with 80 PLUS Bronze efficiency, 120mm silent fan, active PFC, and over-voltage/over-current/short-circuit protection. PCIe, SATA and CPU connectors included.','assets/img/products/PSU-650W-BZ.svg',3295.00,2700.00,15,'Computer Parts',5),
('CASE-ATX-RGB','ATX Mid-Tower Gaming Case with RGB Fans','Mid-tower ATX case with a tempered-glass side panel and three pre-installed RGB fans. Supports ATX, micro-ATX and mini-ITX boards and long graphics cards, with front USB 3.0 and audio ports and dust filters.','assets/img/products/CASE-ATX-RGB.svg',2995.00,2400.00,15,'Computer Parts',5),
('KB-MECH-RGB','Mechanical Gaming Keyboard (RGB)','Wired mechanical keyboard with tactile switches, per-key RGB backlighting with multiple effects, anti-ghosting and a detachable USB cable. Durable build for gaming and long typing sessions.','assets/img/products/KB-MECH-RGB.svg',1995.00,1500.00,15,'Peripherals',5),
('MS-GAMING-7200','Gaming Mouse 7200 DPI','Wired optical gaming mouse with adjustable DPI up to 7200, 6 programmable buttons, RGB lighting and an ergonomic grip. Braided cable for durability.','assets/img/products/MS-GAMING-7200.svg',899.00,600.00,15,'Peripherals',5),
('MON-24-IPS','24" Full HD IPS Monitor 75Hz','24-inch 1920x1080 IPS display with a 75Hz refresh rate, wide viewing angles and thin bezels. HDMI and VGA inputs, tilt-adjustable stand, VESA-mount compatible. Eye-care flicker-free backlight.','assets/img/products/MON-24-IPS.svg',6495.00,5300.00,15,'Peripherals',5)
ON DUPLICATE KEY UPDATE
  `product_name`=VALUES(`product_name`), `description`=VALUES(`description`),
  `image`=VALUES(`image`), `category`=VALUES(`category`);

-- 3) opening-stock ledger entry for each seeded product (once)
INSERT INTO `stock_movements` (`product_id`,`user_id`,`type`,`quantity`,`reference`,`notes`)
SELECT p.id, NULL, 'in', 15, 'OPENING-STOCK', CONCAT('Opening stock: ', p.product_name)
FROM `products` p
WHERE p.product_code IN ('CPU-R5-5600','CPU-I5-12400F','GPU-RTX3060','MB-B550M','RAM-16GB-D4','SSD-NVME-512',
                         'HDD-1TB-7200','PSU-650W-BZ','CASE-ATX-RGB','KB-MECH-RGB','MS-GAMING-7200','MON-24-IPS')
  AND NOT EXISTS (SELECT 1 FROM `stock_movements` m WHERE m.product_id = p.id AND m.reference = 'OPENING-STOCK');
