-- Restrict POS + procurement payments to Cash and PayMongo.
-- The app now only accepts 'cash' and 'paymongo'. Legacy enum values are kept
-- so existing payment records remain valid and still display in history.
ALTER TABLE `payments`
  MODIFY `payment_method` enum('cash','paymongo','bank_transfer','cheque','virtual_card') DEFAULT 'cash';
-- sales.payment_method is a varchar(50); no schema change needed.
