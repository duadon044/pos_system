POS SYSTEM — FINAL PROFESSIONAL BUILD
=====================================

This package is the consolidated offline-ready school project build.

PROFESSIONAL UI
- Redesigned global header, sidebar, cards, tables, forms, buttons and modals.
- Responsive layout for desktop and smaller screens.
- Animated theme transitions.
- Light / Dark mode.
- Six accent palettes: Indigo, Ocean Blue, Emerald, Violet, Rose, Amber.
- Theme and accent selection persist in the browser via localStorage.
- Local Bootstrap, Font Awesome, SweetAlert2 and Chart.js assets.
- No CDN/external frontend asset dependency.

SECURITY / RBAC
- CSRF protection for login, HRM account actions, goods receipt and PO workflows.
- Session ID regeneration after successful login.
- Account status: active, deactivated, archived.
- Deactivation/archive requires a recorded reason.
- Archived accounts can be restored.
- Permanent deletion is restricted to archived accounts and preserves business history by nulling historical user references.
- Added HRM, Inventory, Finance, Cashier and Procurement permission mappings.
- Protected Admin account cannot be deactivated, archived or permanently deleted.
- Central price, quantity and percentage validation helpers.

HRM
- User Accounts moved under Human Resources.
- Employee-linked account directory with search and status filtering.
- Attendance module remains available to HRM.

PROCUREMENT / INVENTORY
- Requisition → RFQ → Supplier → PO → Goods Receipt workflow remains available.
- PO approval now uses the dedicated approve_purchase_orders permission.
- Goods Receipt now has a complete receiving form instead of a visual-only button.
- Received quantities cannot exceed the remaining PO quantity.
- Accepted/rejected quantities must reconcile with received quantity.
- Accepted goods update inventory and create stock movements.
- If a PO item has no linked product, Goods Receipt creates a catalog product under Computer Parts and links it automatically.
- A fully received PO is automatically closed.

VALIDATION
- Prices/costs: 0.00–9,999,999.99 (selling price requires > 0 where applicable).
- Quantities: 0–1,000,000 where zero is valid; positive-only where required.
- Percentages: 0–100.

NOT IMPLEMENTED BY DESIGN
- PayMongo integration remains postponed as previously planned.
- SMTP credentials are not hard-coded. Email delivery can be added later without exposing secrets in the project package.

DATABASE
- Import pos_system.sql into MySQL/MariaDB.
- The SQL contains the enhancement migration plus final role/workflow hardening.
- Development seed remains admin / admin123. Change it before any real deployment.

TESTING PERFORMED
- All PHP files pass php -l syntax checks.
- Global JavaScript passes node --check.
- No CDN asset references were found in the PHP/JS/CSS source.


SMTP / HRMS EMAIL INTEGRATION
-----------------------------
- Added config/mail.php mail service.
- SMTP credentials are NOT stored in MySQL.
- Copy config/mail.local.php.example to config/mail.local.php and fill in your SMTP provider details.
- Install PHPMailer by copying its src folder to vendor/phpmailer/src/.
- HRMS Leave Management sends notification emails when a leave request is recorded and when its status changes.
- Admin System Settings shows PHPMailer/SMTP status and has a test-email button.
- Recommended Gmail configuration: smtp.gmail.com, port 587, STARTTLS, with a Gmail App Password when 2-Step Verification is enabled.

THEME / ICON HARDENING
----------------------
- Theme and accent selection now restores before the page renders, including after logout/login.
- Added local Font Awesome family hardening for legacy `fas` aliases.
- Login and all major pages now preserve the selected local theme/palette.

STABILIZATION PASS — 2026-09-13

- Fixed the bundled Font Awesome webfont paths that caused icons to render as square boxes.
- Improved SweetAlert2 styling, toast feedback, and confirmation dialogs.
- Fixed logout asset/base-path handling and login-page presentation.
- Products: cost may be blank/zero; negative stock/prices are rejected server-side; duplicate product codes are rejected; CSRF added.
- Attendance: CSRF, active-account validation, valid-status validation, and duplicate same-day attendance protection added.
- Leave requests: every new request is forced to Pending; approval/rejection remains an HR review action.
- User Accounts: Create Account action added; deactivation now creates an approval request; Admin/HRM can approve/reject; deactivated accounts have an Activate action; archive/purge remain separate.
- Procurement: fully received POs now create a pending-payment AP invoice record automatically when no invoice exists, so Finance can see it for payment.
- Finance: expense amounts reject negatives; expense deletion was removed; matching active budgets automatically accumulate approved expenses. Budget Management is now view-only.
- Role & Permission UI: permission checkboxes are hidden until Manage Permissions is explicitly opened.
- Offline assets remain bundled locally; no CDN dependency added.
