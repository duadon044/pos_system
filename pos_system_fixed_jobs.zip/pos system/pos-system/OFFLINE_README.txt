POS SYSTEM - OFFLINE FRONTEND NOTE
==================================
Bootstrap 5.3.6 and Font Awesome are bundled under assets/vendor.
The PHP pages were updated to load these local copies instead of CDN URLs.

Database: import pos_system.sql into MySQL/MariaDB.
Connection defaults are in config/database.php.

Note: SweetAlert2 and Chart.js remain external dependencies in the current source where used.
If full no-internet operation for those libraries is required, bundle matching copies under assets/vendor
and update their script references as well.
