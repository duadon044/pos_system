POS SYSTEM — PROFESSIONAL V4 STABILIZED BUILD
================================================

This build is based on the supplied PROFESSIONAL-FINAL-V3 ZIP.

Verified:
- PHP syntax: all PHP files pass php -l
- JavaScript vendor file syntax: passes node --check
- No CDN references detected in PHP/JS/CSS/HTML
- security.php is loaded inside PHP (no raw require_once text)
- Layout includes independent scroll behavior for the sidebar

Major fixes/enhancements:
- Removed manual Product Add button/workflow; catalog products are created from accepted Goods Receipts.
- Product Edit/Delete backend CRUD repaired with validation and transaction-history protection.
- Customer edit UI removed; customers are view-only from the customer directory.
- Automatic employee attendance on login and automatic time-out on logout.
- Employee attendance view is read-only; manual attendance entry removed from the attendance workflow.
- Leave approval/rejection now updates the actual database status; only HR/Admin can review.
- Removed duplicate leave page reload behavior.
- User Accounts now use a View Actions dropdown, with Edit/Promote role assignment, deactivation, restore, archive, and permanent deletion rules.
- Archive requires account_status=deactivated.
- Procurement Goods Receipt fixes accepted/rejected arithmetic and prevents over-receiving; fully received PO becomes fulfilled, not closed.
- Supplier invoice is no longer auto-created by Goods Receipt; Finance can create it and explicitly run 3-Way Match.
- Payment validation prevents negative/overpayment and closes a fulfilled PO only after the invoice is fully paid.
- Stock adjustments now go through Pending -> Approved/Rejected before inventory changes.
- Expenses are Pending until Finance/Admin approval; approved expenses consume the matched active budget.
- Budget creation + Finance/Admin approval workflow added; company revenue is displayed separately.
- Requisition department/cost-centre/unit selections changed to dropdowns.
- Basic HRM Job Postings and Job Applications workflow added, including secure resume upload and SMTP hook.
- Sidebar independent scrolling hardened.
- CSRF verification added to previously unprotected state-changing modules.

IMPORTANT:
1. This is still a local PHP/MySQL school project. SMTP requires PHPMailer + config/mail.local.php credentials.
2. The SQL file contains migrations and new workflow tables. On a disposable/test database, import the complete pos_system.sql into a fresh pos_system database.
3. Do NOT delete XAMPP's whole MySQL data directory. Only remove the project's database folder if a fresh rebuild is necessary and MySQL is stopped.
4. Browser-level testing still requires running the project in XAMPP because this environment does not have a MySQL server/browser session.
