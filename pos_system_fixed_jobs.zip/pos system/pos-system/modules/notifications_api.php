<?php
session_start();
require_once __DIR__ . '/../config/database.php';

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    header('Content-Type: application/json');
    echo json_encode(['ok' => false, 'error' => 'Not logged in']);
    exit();
}

header('Content-Type: application/json');
$db = getDB();
ensure_notifications_table($db);
$userId = (int)$_SESSION['user_id'];
$action = $_GET['action'] ?? ($_POST['action'] ?? 'list');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    if ($action === 'mark_read') {
        $id = (int)($_POST['id'] ?? 0);
        $db->prepare("UPDATE notifications SET is_read=1 WHERE id=? AND user_id=?")->execute([$id, $userId]);
        echo json_encode(['ok' => true]);
        exit();
    }

    if ($action === 'mark_all_read') {
        $db->prepare("UPDATE notifications SET is_read=1 WHERE user_id=? AND is_read=0")->execute([$userId]);
        echo json_encode(['ok' => true]);
        exit();
    }

    echo json_encode(['ok' => false, 'error' => 'Invalid action']);
    exit();
}

// GET — list recent notifications + unread count
$stmt = $db->prepare("SELECT id,title,message,link,is_read,created_at FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 20");
$stmt->execute([$userId]);
$items = $stmt->fetchAll();

$countStmt = $db->prepare("SELECT COUNT(*) FROM notifications WHERE user_id=? AND is_read=0");
$countStmt->execute([$userId]);

echo json_encode(['ok' => true, 'items' => $items, 'unread' => (int)$countStmt->fetchColumn()]);
