<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ' . BASE_PATH . 'login.php');
    exit();
}

if (!hasPermission('view_products')) {
    logActivity("Access denied: products.php - User: " . $_SESSION['username']);
    header('Location: ' . BASE_PATH . 'index.php?error=access_denied');
    exit();
}

$db = getDB();
ensure_product_image_column($db);
$isAjax = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';

$success_message = null;
$error_message = null;
$canManage = (int)($_SESSION['role_id'] ?? 0) === 1 || hasPermission('manage_products');

// A photo bigger than post_max_size makes PHP drop the whole form; say so clearly.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($_POST) && empty($_FILES) && (int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
    $msg = 'The upload is too large for the server (post_max_size ' . ini_get('post_max_size') . '). Choose a smaller photo.';
    if ($isAjax) { header('Content-Type: application/json'); echo json_encode(['success'=>false,'message'=>$msg]); exit(); }
    $error_message = $msg;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$error_message) {
    verify_csrf();
    try {
        if (isset($_POST['add_product'])) {
            require_permission('manage_products');
            $code=trim($_POST['product_code']??''); $name=trim($_POST['product_name']??'');
            $price=$_POST['price']??''; $cost=$_POST['cost']??''; $category=trim($_POST['category']??'');
            $threshold=$_POST['low_stock_threshold']??5;
            if($code===''||$name==='') throw new Exception('Product code and name are required.');
            if(!valid_money($price,false)||!valid_money($cost,true)||!valid_qty($threshold,true)) throw new Exception('Invalid product values.');
            $dup=$db->prepare('SELECT id FROM products WHERE product_code=? LIMIT 1'); $dup->execute([$code]);
            if($dup->fetch()) throw new Exception('Product code already exists.');
            $image = null;
            if (!empty($_FILES['image']['name'])) $image = save_product_image($_FILES['image']);
            try {
                $stmt=$db->prepare('INSERT INTO products(product_code,product_name,description,image,price,cost,stock_quantity,category,low_stock_threshold) VALUES(?,?,?,?,?,?,0,?,?)');
                $stmt->execute([$code,$name,sanitize($_POST['description']??''),$image,(float)$price,(float)$cost,$category,(int)$threshold]);
            } catch (Throwable $e) { delete_product_image($image); throw $e; }
            logActivity("Added product: {$name} ({$code})"); $success_message='Product added. Use Goods Receipt or Stock Movement to add stock.';
        } elseif (isset($_POST['edit_product'])) {
            require_permission('manage_products');
            $id=(int)($_POST['product_id']??0);
            $code=trim($_POST['product_code']??''); $name=trim($_POST['product_name']??'');
            $price=$_POST['price']??''; $cost=$_POST['cost']??''; $category=trim($_POST['category']??'');
            $threshold=$_POST['low_stock_threshold']??5;
            if($id<=0||$code===''||$name==='') throw new Exception('Product code and name are required.');
            if(!valid_money($price,false)||!valid_money($cost,true)||!valid_qty($threshold,true)) throw new Exception('Invalid product values.');
            $dup=$db->prepare('SELECT id FROM products WHERE product_code=? AND id<>? LIMIT 1'); $dup->execute([$code,$id]);
            if($dup->fetch()) throw new Exception('Product code already exists.');
            $oldStmt=$db->prepare('SELECT image FROM products WHERE id=?'); $oldStmt->execute([$id]);
            $oldImage=$oldStmt->fetchColumn();
            $image=$oldImage; $imageChanged=false;
            if (!empty($_FILES['image']['name'])) { $image = save_product_image($_FILES['image']); $imageChanged=true; }
            elseif (!empty($_POST['remove_image'])) { $image = null; $imageChanged=true; }
            try {
                $stmt=$db->prepare('UPDATE products SET product_code=?,product_name=?,description=?,image=?,price=?,cost=?,category=?,low_stock_threshold=? WHERE id=?');
                $stmt->execute([$code,$name,sanitize($_POST['description']??''),$image,(float)$price,(float)$cost,$category,(int)$threshold,$id]);
            } catch (Throwable $e) { if ($imageChanged) delete_product_image($image); throw $e; }
            if ($imageChanged) delete_product_image($oldImage);
            logActivity("Updated product #{$id}: {$name}"); $success_message='Product updated successfully.';
        } elseif(isset($_POST['delete_product'])) {
            require_permission('manage_products');
            $id=(int)($_POST['product_id']??0);
            if($id<=0) throw new Exception('Invalid product.');
            $refs=$db->prepare('SELECT (SELECT COUNT(*) FROM sales_items WHERE product_id=?) + (SELECT COUNT(*) FROM stock_movements WHERE product_id=?) AS c');
            $refs->execute([$id,$id]);
            if((int)$refs->fetchColumn()>0) throw new Exception('This product has transaction history and cannot be deleted. Keep it for audit/history.');
            $imgStmt=$db->prepare('SELECT image FROM products WHERE id=?'); $imgStmt->execute([$id]); $oldImage=$imgStmt->fetchColumn();
            $db->prepare('DELETE FROM products WHERE id=?')->execute([$id]);
            delete_product_image($oldImage);
            logActivity("Deleted product #{$id}"); $success_message='Product deleted successfully.';
        }
    } catch(Throwable $e) { $error_message=$e->getMessage(); }
}

if($_SERVER['REQUEST_METHOD']==='POST' && $isAjax){header('Content-Type: application/json');echo json_encode(['success'=>$error_message===null,'message'=>$error_message??$success_message]);exit();}

$products = $db->query("SELECT * FROM products ORDER BY created_at DESC")->fetchAll();
foreach ($products as &$__p) { $__p['image_url'] = product_image_url($__p['image'] ?? ''); $__p['has_photo'] = !empty($__p['image']); }
unset($__p);

$stats = [
    'total' => $db->query("SELECT COUNT(*) FROM products")->fetchColumn(),
    'low_stock' => $db->query("SELECT COUNT(*) FROM products WHERE stock_quantity <= low_stock_threshold")->fetchColumn(),
    'out_of_stock' => $db->query("SELECT COUNT(*) FROM products WHERE stock_quantity = 0")->fetchColumn(),
];
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light" data-pos-theme="light" data-pos-palette="indigo">
<head>
<script>
(function(){try{var t=localStorage.getItem('pos_theme');if(t!=='dark'&&t!=='light')t='light';var r=document.documentElement;r.setAttribute('data-pos-theme',t);r.setAttribute('data-bs-theme',t);}catch(e){}})();
</script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products</title>
    <link href="<?php echo BASE_PATH; ?>assets/vendor/bootstrap/bootstrap.min.css?v=20261005" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo BASE_PATH; ?>assets/vendor/fontawesome/all.min.css?v=20261005">
    <link rel="stylesheet" href="<?php echo BASE_PATH; ?>assets/css/custom.css?v=20261005">
</head>
<body>
    <?php include BASE_PATH . 'includes/header.php'; ?>
    
    <div class="d-flex">
        <?php include BASE_PATH . 'includes/sidebar.php'; ?>
        
        <div class="main-content flex-grow-1 p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h4 class="mb-0"><i class="fas fa-boxes me-2 text-primary"></i> Products</h4>
                <?php if ($canManage): ?>
                <button type="button" class="btn btn-primary" id="addProductBtn"><i class="fas fa-plus me-1"></i> Add Product</button>
                <?php endif; ?>
            </div>
            
            <?php if (isset($success_message)): ?>
                <div id="flash-message" data-type="success" data-message="<?php echo htmlspecialchars($success_message); ?>"></div>
            <?php endif; ?>
            <?php if (isset($error_message)): ?>
                <div id="flash-message" data-type="error" data-message="<?php echo htmlspecialchars($error_message); ?>"></div>
            <?php endif; ?>
            
            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h6 class="text-muted">Total Products</h6>
                            <h3 class="fw-bold text-primary"><?php echo $stats['total']; ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h6 class="text-muted">Low Stock</h6>
                            <h3 class="fw-bold text-warning"><?php echo $stats['low_stock']; ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h6 class="text-muted">Out of Stock</h6>
                            <h3 class="fw-bold text-danger"><?php echo $stats['out_of_stock']; ?></h3>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card border-0 shadow-sm">
                <div class="card-body table-responsive">
                    <table class="table table-hover" id="productsTable">
                        <thead>
                            <tr>
                                <th>Image</th>
                                <th>Code</th>
                                <th>Product Name</th>
                                <th>Category</th>
                                <th>Price</th>
                                <th>Cost</th>
                                <th>Stock</th>
                                <th>Threshold</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($products as $product): ?>
                            <tr id="product-row-<?php echo $product['id']; ?>" class="product-row" data-id="<?php echo $product['id']; ?>" title="Click to view details">
                                <td><img src="<?php echo htmlspecialchars($product['image_url']); ?>" alt="<?php echo htmlspecialchars($product['product_name']); ?>" class="product-thumb" loading="lazy" width="64" height="48"></td>
                                <td><span class="badge bg-secondary"><?php echo htmlspecialchars($product['product_code']); ?></span></td>
                                <td><strong><?php echo htmlspecialchars($product['product_name']); ?></strong>
                                    <?php if (!empty($product['description'])): ?><div class="product-desc small text-muted"><?php echo htmlspecialchars($product['description']); ?></div><?php endif; ?></td>
                                <td><?php echo htmlspecialchars($product['category'] ?: '-'); ?></td>
                                <td>₱<?php echo number_format($product['price'], 2); ?></td>
                                <td>₱<?php echo number_format($product['cost'], 2); ?></td>
                                <td>
                                    <?php
                                    $stockClass = 'success';
                                    if ($product['stock_quantity'] <= 0) {
                                        $stockClass = 'danger';
                                    } elseif ($product['stock_quantity'] <= $product['low_stock_threshold']) {
                                        $stockClass = 'warning';
                                    }
                                    ?>
                                    <span class="badge bg-<?php echo $stockClass; ?>">
                                        <?php echo $product['stock_quantity']; ?>
                                    </span>
                                </td>
                                <td><?php echo $product['low_stock_threshold']; ?></td>
                                <td class="text-nowrap">
                                    <button class="btn btn-sm btn-outline-primary view-product" data-id="<?php echo $product['id']; ?>" title="View details">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <?php if ($canManage): ?>
                                    <button class="btn btn-sm btn-primary edit-product" data-id="<?php echo $product['id']; ?>" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-danger delete-product" data-id="<?php echo $product['id']; ?>" data-name="<?php echo htmlspecialchars($product['product_name']); ?>" title="Delete">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>


    <!-- View product -->
    <div class="modal fade" id="productViewModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-box-open me-2 text-primary"></i><span id="pvTitle">Product</span></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-4">
                        <div class="col-md-5">
                            <div class="product-view-img-wrap"><img id="pvImage" src="" alt="" class="product-view-img"></div>
                            <a id="pvImageLink" href="#" target="_blank" rel="noopener" class="btn btn-sm btn-outline-secondary w-100 mt-2"><i class="fas fa-up-right-and-down-left-from-center me-1"></i> View full size</a>
                        </div>
                        <div class="col-md-7">
                            <div class="d-flex flex-wrap gap-2 mb-2">
                                <span class="badge bg-secondary" id="pvCode"></span>
                                <span class="badge bg-info text-dark" id="pvCategory"></span>
                                <span class="badge" id="pvStatus"></span>
                            </div>
                            <div class="row g-2 mb-3">
                                <div class="col-6"><div class="pv-stat"><div class="small text-muted">Selling price</div><div class="fs-5 fw-bold text-primary" id="pvPrice"></div></div></div>
                                <div class="col-6"><div class="pv-stat"><div class="small text-muted">Cost</div><div class="fs-5 fw-bold" id="pvCost"></div></div></div>
                                <div class="col-6"><div class="pv-stat"><div class="small text-muted">In stock</div><div class="fs-5 fw-bold" id="pvStock"></div></div></div>
                                <div class="col-6"><div class="pv-stat"><div class="small text-muted">Profit / unit</div><div class="fs-5 fw-bold" id="pvMargin"></div></div></div>
                            </div>
                            <div class="small text-muted mb-1">Low stock alert at</div>
                            <div class="mb-3" id="pvThreshold"></div>
                            <div class="small text-muted mb-1">Description</div>
                            <div id="pvDesc" class="pv-desc"></div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <?php if ($canManage): ?><button type="button" class="btn btn-primary" id="pvEditBtn"><i class="fas fa-edit me-1"></i> Edit</button><?php endif; ?>
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <?php if ($canManage): ?>
    <!-- Add / edit product -->
    <div class="modal fade" id="productFormModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <form id="productForm" enctype="multipart/form-data" autocomplete="off">
                    <div class="modal-header">
                        <h5 class="modal-title"><i class="fas fa-box me-2 text-primary"></i><span id="pfTitle">Add Product</span></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label">Photo</label>
                                <div class="photo-drop" id="pfDrop">
                                    <img id="pfPreview" src="" alt="Product photo preview">
                                </div>
                                <input type="file" class="form-control form-control-sm mt-2" id="pfImage" name="image" accept="image/jpeg,image/png,image/webp,image/gif">
                                <div class="form-text">JPG, PNG, WEBP or GIF · max 4 MB</div>
                                <div class="form-check mt-2 d-none" id="pfRemoveWrap">
                                    <input class="form-check-input" type="checkbox" id="pfRemove" name="remove_image" value="1">
                                    <label class="form-check-label small" for="pfRemove">Remove current photo</label>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="row g-3">
                                    <div class="col-sm-5"><label class="form-label" for="pfCode">Product code <span class="text-danger">*</span></label><input class="form-control" id="pfCode" name="product_code" required maxlength="50"></div>
                                    <div class="col-sm-7"><label class="form-label" for="pfName">Product name <span class="text-danger">*</span></label><input class="form-control" id="pfName" name="product_name" required maxlength="150"></div>
                                    <div class="col-sm-6"><label class="form-label" for="pfCategory">Category</label><input class="form-control" id="pfCategory" name="category" maxlength="100"></div>
                                    <div class="col-sm-6"><label class="form-label" for="pfThreshold">Low stock threshold</label><input type="number" min="0" step="1" class="form-control" id="pfThreshold" name="low_stock_threshold" value="5"></div>
                                    <div class="col-sm-6"><label class="form-label" for="pfPrice">Selling price (₱) <span class="text-danger">*</span></label><input type="number" min="0.01" step="0.01" class="form-control" id="pfPrice" name="price" required></div>
                                    <div class="col-sm-6"><label class="form-label" for="pfCost">Cost (₱)</label><input type="number" min="0" step="0.01" class="form-control" id="pfCost" name="cost" value="0"></div>
                                    <div class="col-12"><label class="form-label" for="pfDesc">Description</label><textarea class="form-control" id="pfDesc" name="description" rows="3"></textarea></div>
                                </div>
                            </div>
                        </div>
                        <div class="alert alert-info border-0 small mt-3 mb-0 d-none" id="pfStockNote"><i class="fas fa-circle-info me-1"></i> New products start with 0 stock. Add stock through Goods Receipt or Stock Movement.</div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" id="pfSave"><i class="fas fa-save me-1"></i> <span id="pfSaveText">Save</span></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <script src="<?php echo BASE_PATH; ?>assets/vendor/sweetalert2/sweetalert2.all.min.js?v=20261005"></script>
    <script src="<?php echo BASE_PATH; ?>assets/vendor/bootstrap/bootstrap.bundle.min.js?v=20261005"></script>
    <script src="<?php echo BASE_PATH; ?>assets/js/script.js?v=20261005"></script>
    
    <script>
        // (no #productForm on this page - products are edited via the Swal dialog below)
        
        
    </script>

<script>
const productData = <?php echo json_encode($products, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT); ?>;
const csrfToken = <?php echo json_encode(csrf_token()); ?>;
const canManage = <?php echo $canManage ? 'true' : 'false'; ?>;
const PLACEHOLDER = <?php echo json_encode(product_image_url('')); ?>;
const peso = n => '₱' + Number(n || 0).toLocaleString('en-PH', {minimumFractionDigits: 2, maximumFractionDigits: 2});
// Descriptions are stored HTML-escaped by the server; turn them back into plain text for display/editing.
function plain(v){ const t = document.createElement('textarea'); t.innerHTML = String(v == null ? '' : v); return t.value; }
function escapeHtml(v){return String(v).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));}
const byId = id => productData.find(x => Number(x.id) === Number(id));

/* ---------- View product ---------- */
const viewEl = document.getElementById('productViewModal');
const viewModal = new bootstrap.Modal(viewEl);
let viewingId = null;

function openView(id){
  const p = byId(id); if (!p) return;
  viewingId = p.id;
  const stock = Number(p.stock_quantity), thr = Number(p.low_stock_threshold);
  document.getElementById('pvTitle').textContent = plain(p.product_name);
  const img = document.getElementById('pvImage');
  img.src = p.image_url; img.alt = plain(p.product_name);
  img.onerror = () => { img.onerror = null; img.src = PLACEHOLDER; };
  document.getElementById('pvImageLink').href = p.image_url;
  document.getElementById('pvCode').textContent = p.product_code;
  const cat = document.getElementById('pvCategory');
  cat.textContent = p.category || 'Uncategorized';
  const st = document.getElementById('pvStatus');
  if (stock <= 0) { st.className = 'badge bg-danger'; st.textContent = 'Out of stock'; }
  else if (stock <= thr) { st.className = 'badge bg-warning text-dark'; st.textContent = 'Low stock'; }
  else { st.className = 'badge bg-success'; st.textContent = 'In stock'; }
  document.getElementById('pvPrice').textContent = peso(p.price);
  document.getElementById('pvCost').textContent = peso(p.cost);
  document.getElementById('pvStock').textContent = stock + ' pcs';
  const profit = Number(p.price) - Number(p.cost || 0);
  const pct = Number(p.price) > 0 ? (profit / Number(p.price) * 100) : 0;
  document.getElementById('pvMargin').textContent = peso(profit) + ' (' + pct.toFixed(0) + '%)';
  document.getElementById('pvThreshold').textContent = thr + ' pcs';
  const d = plain(p.description).trim();
  const descEl = document.getElementById('pvDesc');
  descEl.textContent = d || 'No description.';
  descEl.classList.toggle('text-muted', !d);
  viewModal.show();
}

document.querySelectorAll('.product-row').forEach(row => row.addEventListener('click', e => {
  if (e.target.closest('button, a, input')) return;   // action buttons do their own thing
  openView(row.dataset.id);
}));
document.querySelectorAll('.view-product').forEach(btn => btn.addEventListener('click', () => openView(btn.dataset.id)));

/* ---------- Add / edit product ---------- */
if (canManage) {
  const formEl = document.getElementById('productForm');
  const formModal = new bootstrap.Modal(document.getElementById('productFormModal'));
  const $ = id => document.getElementById(id);
  let mode = 'add', editId = null, objectUrl = null;

  function setPreview(src){ $('pfPreview').src = src; }
  function resetPreviewUrl(){ if (objectUrl) { URL.revokeObjectURL(objectUrl); objectUrl = null; } }

  function openForm(p){
    formEl.reset(); resetPreviewUrl();
    mode = p ? 'edit' : 'add'; editId = p ? p.id : null;
    $('pfTitle').textContent = p ? 'Edit Product' : 'Add Product';
    $('pfSaveText').textContent = p ? 'Save Changes' : 'Add Product';
    $('pfStockNote').classList.toggle('d-none', !!p);
    $('pfRemoveWrap').classList.toggle('d-none', !(p && p.has_photo));
    if (p) {
      $('pfCode').value = p.product_code; $('pfName').value = plain(p.product_name);
      $('pfCategory').value = plain(p.category || ''); $('pfPrice').value = p.price;
      $('pfCost').value = p.cost || 0; $('pfThreshold').value = p.low_stock_threshold;
      $('pfDesc').value = plain(p.description || '');
      setPreview(p.image_url);
    } else { setPreview(PLACEHOLDER); }
    formModal.show();
  }

  $('addProductBtn').addEventListener('click', () => openForm(null));
  document.querySelectorAll('.edit-product').forEach(btn => btn.addEventListener('click', () => { const p = byId(btn.dataset.id); if (p) openForm(p); }));
  $('pvEditBtn').addEventListener('click', () => {
    const p = byId(viewingId); if (!p) return;
    viewEl.addEventListener('hidden.bs.modal', () => openForm(p), { once: true });
    viewModal.hide();
  });

  // live preview of the chosen photo
  $('pfImage').addEventListener('change', function(){
    const f = this.files && this.files[0];
    resetPreviewUrl();
    if (!f) { setPreview(mode === 'edit' ? byId(editId).image_url : PLACEHOLDER); return; }
    if (!/^image\/(jpeg|png|webp|gif)$/.test(f.type)) { this.value = ''; showError('Please choose a JPG, PNG, WEBP or GIF image.'); return; }
    if (f.size > 4 * 1024 * 1024) { this.value = ''; showError('That photo is larger than 4 MB. Please choose a smaller one.'); return; }
    objectUrl = URL.createObjectURL(f); setPreview(objectUrl);
    $('pfRemove').checked = false;
  });
  $('pfRemove').addEventListener('change', function(){
    if (this.checked) { $('pfImage').value = ''; resetPreviewUrl(); setPreview(PLACEHOLDER); }
    else setPreview(byId(editId).image_url);
  });

  formEl.addEventListener('submit', function(e){
    e.preventDefault();
    if (!formEl.reportValidity()) return;
    const fd = new FormData(formEl);
    fd.append('csrf_token', csrfToken);
    fd.append(mode === 'add' ? 'add_product' : 'edit_product', '1');
    if (mode === 'edit') fd.append('product_id', editId);
    const btn = $('pfSave'); btn.disabled = true; $('pfSaveText').textContent = 'Saving…';
    fetch('', { method: 'POST', headers: { 'X-Requested-With': 'XMLHttpRequest' }, body: fd })
      .then(r => r.json())
      .then(d => {
        if (!d.success) { showError(d.message || 'Unable to save the product.'); return; }
        formModal.hide();
        Promise.resolve(showSuccess(d.message || 'Saved.')).then(() => location.reload());
      })
      .catch(() => showError('Request failed. Please try again.'))
      .finally(() => { btn.disabled = false; $('pfSaveText').textContent = mode === 'edit' ? 'Save Changes' : 'Add Product'; });
  });
}

/* ---------- Delete ---------- */
document.querySelectorAll('.delete-product').forEach(btn=>btn.addEventListener('click',()=>{
 confirmAction(`Delete <strong>${escapeHtml(btn.dataset.name)}</strong>? Products with transaction history cannot be deleted.`,'Delete',()=>{
  const f=new FormData();f.append('csrf_token',csrfToken);f.append('delete_product','1');f.append('product_id',btn.dataset.id);
  fetch('',{method:'POST',headers:{'X-Requested-With':'XMLHttpRequest'},body:f}).then(r=>r.json()).then(d=>{if(d.success)location.reload();else showError(d.message||'Delete failed.');}).catch(()=>showError('Delete failed.'));
 });
}));
</script>

</body>
</html>