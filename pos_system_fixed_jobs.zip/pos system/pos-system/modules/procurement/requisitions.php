<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ' . BASE_PATH . 'login.php');
    exit();
}

$db = getDB();
verify_csrf();

$success_message = null;
$error_message = null;

// SIMPLIFIED VERSION - KOPYA NG TEST
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['create_requisition'])) {
    require_permission('create_requisitions');

    $department = trim($_POST['department'] ?? '');
    $cost_centre = trim($_POST['cost_centre'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $estimated_value = (float)($_POST['estimated_value'] ?? 0);
    $urgency = $_POST['urgency'] ?? 'medium';
    $requester_id = $_SESSION['user_id'];
    $req_number = 'REQ-' . date('Ymd') . '-' . rand(1000, 9999);

    // Step 1: Need Identification — link the request to a real budget code so
    // the availability check in Step 2 has something to check against, and to
    // a budget owner so they can be notified for initial awareness.
    $budget_code = trim($_POST['budget_code'] ?? '');
    $budget_owner_id = (int)($_POST['budget_owner_id'] ?? 0);

    if ($budget_code !== '') {
        $bc = $db->prepare("SELECT id FROM budgets WHERE budget_code = ? AND status = 'active'");
        $bc->execute([$budget_code]);
        if (!$bc->fetchColumn()) {
            $error_message = "Selected budget code is not active or no longer exists.";
        }
    }
    if ($budget_owner_id > 0 && $error_message === null) {
        $bo = $db->prepare("SELECT id FROM users WHERE id = ?");
        $bo->execute([$budget_owner_id]);
        if (!$bo->fetchColumn()) {
            $budget_owner_id = 0;
        }
    } else {
        $budget_owner_id = 0;
    }

    if ($error_message === null && (empty($department) || empty($cost_centre) || empty($description) || $estimated_value <= 0)) {
        $error_message = "Please fill in all required fields!";
    } elseif ($error_message === null) {
        try {
            $db->beginTransaction();
            
            // Insert requisition
            $stmt = $db->prepare("INSERT INTO requisitions (req_number, requester_id, department, cost_centre, description, estimated_value, urgency, status, budget_code, budget_owner_id) 
                                   VALUES (?, ?, ?, ?, ?, ?, ?, 'pending_budget', ?, ?)");
            $stmt->execute([$req_number, $requester_id, $department, $cost_centre, $description, $estimated_value, $urgency, $budget_code !== '' ? $budget_code : null, $budget_owner_id ?: null]);
            $req_id = $db->lastInsertId();
            
            // Insert items
            $items = $_POST['items'] ?? [];
            $item_count = 0;
            foreach ($items as $item) {
                if (!empty($item['description']) && !empty($item['quantity']) && !empty($item['estimated_price'])) {
                    $total = (float)$item['quantity'] * (float)$item['estimated_price'];
                    $stmt = $db->prepare("INSERT INTO requisition_items (requisition_id, item_description, quantity, unit, estimated_price, total) 
                                           VALUES (?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$req_id, $item['description'], (int)$item['quantity'], $item['unit'] ?? '', (float)$item['estimated_price'], $total]);
                    $item_count++;
                }
            }
            
            if ($item_count == 0) {
                throw new Exception("Please add at least one item!");
            }
            
            $db->commit();
            $notifyMsg = $budget_owner_id ? " Budget owner has been notified for initial awareness." : "";
            $success_message = "Requisition #$req_number created successfully!" . $notifyMsg;
            logActivity("Created requisition #$req_number" . ($budget_owner_id ? " (budget owner notified: user #$budget_owner_id)" : ""));
            
            header('Location: ' . BASE_PATH . 'modules/procurement/requisitions.php?success=' . urlencode("Requisition #$req_number created!" . $notifyMsg));
            exit();
            
        } catch(Exception $e) {
            $db->rollBack();
            $error_message = "Error: " . $e->getMessage();
        }
    }
}

// BUDGET APPROVAL — Step 2: Finance (or automated budget controls) checks that
// funds are actually available against the requisition's budget code before
// approving. Over-budget requests are auto-rejected and must be reallocated.
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['approve_budget'])) {
    require_permission('approve_requisitions');
    $req_id = (int)$_POST['requisition_id'];
    $action = $_POST['action'];
    $remarks = sanitize($_POST['remarks']);

    try {
        $db->beginTransaction();

        $r = $db->prepare("SELECT * FROM requisitions WHERE id = ? FOR UPDATE");
        $r->execute([$req_id]);
        $req = $r->fetch();
        if (!$req) throw new Exception('Requisition not found.');
        if ($req['status'] !== 'pending_budget') throw new Exception('This requisition has already been reviewed.');

        $budget = null;
        if (!empty($req['budget_code'])) {
            $b = $db->prepare("SELECT * FROM budgets WHERE budget_code = ? FOR UPDATE");
            $b->execute([$req['budget_code']]);
            $budget = $b->fetch();
        }

        if ($action === 'approve') {
            if ($budget) {
                $remaining = (float)$budget['allocated_amount'] - (float)$budget['used_amount'];
                if ($budget['status'] !== 'active') {
                    // Budget isn't active/approved yet — cannot reserve funds against it.
                    $action = 'reject';
                    $remarks = trim('Budget code ' . $req['budget_code'] . ' is not active. ' . $remarks);
                } elseif ((float)$req['estimated_value'] > $remaining) {
                    // Over budget → auto-reject and ask for reallocation, per Step 2.
                    $action = 'reject';
                    $remarks = trim(sprintf(
                        'Auto-rejected: insufficient funds in %s. Requested ₱%s, remaining ₱%s. Please reallocate budget or revise the requisition. %s',
                        $req['budget_code'], number_format($req['estimated_value'], 2), number_format($remaining, 2), $remarks
                    ));
                }
            }
        }

        if ($action === 'approve') {
            $status = 'budget_approved';
            $db->prepare("UPDATE requisitions SET status = ?, finance_remarks = ?, budget_used = ? WHERE id = ?")
               ->execute([$status, $remarks, $req['estimated_value'], $req_id]);
            if ($budget) {
                $db->prepare("UPDATE budgets SET used_amount = used_amount + ? WHERE id = ?")
                   ->execute([$req['estimated_value'], $budget['id']]);
            }
        } else {
            $status = 'budget_rejected';
            $db->prepare("UPDATE requisitions SET status = ?, finance_remarks = ? WHERE id = ?")
               ->execute([$status, $remarks, $req_id]);
        }

        $db->commit();
        $success_message = "Budget " . ($status === 'budget_approved' ? 'approved' : 'rejected') . "!";
        logActivity("Requisition #{$req_id} budget " . ($status === 'budget_approved' ? 'approved' : 'rejected'));
        header('Location: ' . BASE_PATH . 'modules/procurement/requisitions.php?success=' . urlencode($success_message));
        exit();
    } catch (Throwable $e) {
        if ($db->inTransaction()) $db->rollBack();
        $error_message = $e->getMessage();
    }
}

// FETCH DATA
$requisitions = $db->query("
    SELECT r.*, u.full_name as requester, bo.full_name as budget_owner_name
    FROM requisitions r 
    JOIN users u ON r.requester_id = u.id 
    LEFT JOIN users bo ON r.budget_owner_id = bo.id
    ORDER BY r.created_at DESC
")->fetchAll();

// Active budgets, for linking a requisition to a real budget code (Step 1/2).
$activeBudgets = $db->query("SELECT id, budget_code, department, category, allocated_amount, used_amount FROM budgets WHERE status = 'active' ORDER BY department, category")->fetchAll();

// Finance/Admin users who can be assigned as the budget owner to notify (Step 1).
$budgetOwners = $db->query("
    SELECT u.id, u.full_name, r.role_name
    FROM users u JOIN roles r ON u.role_id = r.id
    WHERE r.role_name IN ('Finance','Admin')
    ORDER BY u.full_name
")->fetchAll();

if (isset($_GET['success'])) {
    $success_message = htmlspecialchars($_GET['success']);
}
if (isset($_GET['error'])) {
    $error_message = htmlspecialchars($_GET['error']);
}
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light" data-pos-theme="light" data-pos-palette="indigo">
<head>
<script>
(function(){try{var t=localStorage.getItem('pos_theme');if(t!=='dark'&&t!=='light')t='light';var r=document.documentElement;r.setAttribute('data-pos-theme',t);r.setAttribute('data-bs-theme',t);}catch(e){}})();
</script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Requisitions</title>
    <link href="<?php echo BASE_PATH; ?>assets/vendor/bootstrap/bootstrap.min.css?v=20261005" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo BASE_PATH; ?>assets/vendor/fontawesome/all.min.css?v=20261005">
    <link rel="stylesheet" href="<?php echo BASE_PATH; ?>assets/css/custom.css?v=20261005">
</head>
<body>
    <?php include BASE_PATH . 'includes/header.php'; ?>
    
    <div class="d-flex">
        <?php include BASE_PATH . 'includes/sidebar.php'; ?>
        
        <div class="main-content flex-grow-1 p-4">
            <h4 class="mb-4"><i class="fas fa-file-invoice me-2 text-primary"></i> Requisitions</h4>
            
            <?php if ($success_message): ?>
                <div id="flash-message" data-type="success" data-message="<?php echo $success_message; ?>"></div>
            <?php endif; ?>
            <?php if ($error_message): ?>
                <div id="flash-message" data-type="error" data-message="<?php echo $error_message; ?>"></div>
            <?php endif; ?>
            
            <!-- FORM -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-transparent">
                    <h5 class="mb-0"><i class="fas fa-plus-circle me-2 text-primary"></i> New Requisition</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <?php echo csrf_field(); ?>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Department <span class="text-danger">*</span></label>
                                <select name="department" class="form-select" required><option value="">Select department</option><?php foreach(["IT","HR","Finance","Operations","Sales","Marketing","Procurement","Warehouse"] as $d): ?><option value="<?php echo h($d); ?>"><?php echo h($d); ?></option><?php endforeach; ?></select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Cost Centre <span class="text-danger">*</span></label>
                                <select name="cost_centre" class="form-select" required><option value="">Select cost centre</option><?php foreach(["CC-IT","CC-HR","CC-FIN","CC-OPS","CC-SALES","CC-MKT","CC-PROC","CC-WH"] as $c): ?><option value="<?php echo h($c); ?>"><?php echo h($c); ?></option><?php endforeach; ?></select>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Description <span class="text-danger">*</span></label>
                                <textarea name="description" class="form-control" rows="2" required></textarea>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Estimated Value (₱) <span class="text-danger">*</span></label>
                                <input type="number" step="0.01" name="estimated_value" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Budget Code <span class="text-muted">(optional)</span></label>
                                <select name="budget_code" class="form-select">
                                    <option value="">No specific budget code</option>
                                    <?php foreach($activeBudgets as $b): $remaining = $b['allocated_amount'] - $b['used_amount']; ?>
                                    <option value="<?php echo h($b['budget_code']); ?>"><?php echo h($b['budget_code']); ?> — <?php echo h($b['department']); ?>/<?php echo h($b['category']); ?> (₱<?php echo number_format($remaining, 2); ?> remaining)</option>
                                    <?php endforeach; ?>
                                </select>
                                <small class="text-muted">Linking a code lets Finance run an automatic funds-availability check.</small>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Budget Owner to Notify <span class="text-muted">(optional)</span></label>
                                <select name="budget_owner_id" class="form-select">
                                    <option value="">None</option>
                                    <?php foreach($budgetOwners as $bo): ?>
                                    <option value="<?php echo (int)$bo['id']; ?>"><?php echo h($bo['full_name']); ?> (<?php echo h($bo['role_name']); ?>)</option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Urgency</label>
                                <select name="urgency" class="form-select">
                                    <option value="low">Low</option>
                                    <option value="medium" selected>Medium</option>
                                    <option value="high">High</option>
                                    <option value="critical">Critical</option>
                                </select>
                            </div>
                            
                            <div class="col-12">
                                <h6>Items <span class="text-danger">*</span></h6>
                                <div id="items-container">
                                    <div class="row g-2 item-row">
                                        <div class="col-4">
                                            <input type="text" name="items[0][description]" class="form-control" placeholder="Item description" required>
                                        </div>
                                        <div class="col-2">
                                            <input type="number" name="items[0][quantity]" class="form-control" placeholder="Qty" required>
                                        </div>
                                        <div class="col-2">
                                            <select name="items[0][unit]" class="form-select"><option value="pcs">pcs</option><option value="unit">unit</option><option value="box">box</option><option value="set">set</option><option value="pack">pack</option></select>
                                        </div>
                                        <div class="col-3">
                                            <input type="number" step="0.01" name="items[0][estimated_price]" class="form-control" placeholder="Price" required>
                                        </div>
                                        <div class="col-1">
                                            <button type="button" class="btn btn-danger btn-sm" onclick="this.closest('.item-row').remove()">
                                                <i class="fas fa-times"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <button type="button" class="btn btn-secondary btn-sm mt-2" onclick="addItemRow()">
                                    <i class="fas fa-plus me-1"></i> Add Item
                                </button>
                            </div>
                            
                            <div class="col-12">
                                <button type="submit" name="create_requisition" class="btn btn-primary">
                                    <i class="fas fa-paper-plane me-1"></i> Submit Requisition
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- LIST -->
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-transparent">
                    <h5 class="mb-0"><i class="fas fa-list me-2 text-primary"></i> Requisition List</h5>
                    <small>Total: <?php echo count($requisitions); ?></small>
                </div>
                <div class="card-body table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Requester</th>
                                <th>Department</th>
                                <th>Budget Code</th>
                                <th>Budget Owner</th>
                                <th>Value</th>
                                <th>Status</th>
                                <th>Created</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($requisitions)): ?>
                            <tr>
                                <td colspan="9" class="text-center text-muted">No requisitions found</td>
                            </tr>
                            <?php else: ?>
                            <?php foreach($requisitions as $req): $isMyBudget = $req['budget_owner_id'] && (int)$req['budget_owner_id'] === (int)$_SESSION['user_id']; ?>
                            <tr<?php echo ($isMyBudget && $req['status'] === 'pending_budget') ? ' class="table-warning"' : ''; ?>>
                                <td><strong><?php echo $req['req_number']; ?></strong></td>
                                <td><?php echo $req['requester']; ?></td>
                                <td><?php echo $req['department']; ?></td>
                                <td><?php echo $req['budget_code'] ? h($req['budget_code']) : '<span class="text-muted">—</span>'; ?></td>
                                <td>
                                    <?php if ($req['budget_owner_name']): ?>
                                        <?php echo h($req['budget_owner_name']); ?>
                                        <?php if ($isMyBudget && $req['status'] === 'pending_budget'): ?><span class="badge bg-warning text-dark ms-1">Awaiting your review</span><?php endif; ?>
                                    <?php else: ?><span class="text-muted">—</span><?php endif; ?>
                                </td>
                                <td>₱<?php echo number_format($req['estimated_value'], 2); ?></td>
                                <td>
                                    <span class="badge bg-<?php echo $req['status'] === 'budget_approved' ? 'success' : ($req['status'] === 'pending_budget' ? 'warning' : 'secondary'); ?>">
                                        <?php echo str_replace('_', ' ', $req['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo date('M d, Y', strtotime($req['created_at'])); ?></td>
                                <td>
                                    <?php if ($req['status'] === 'pending_budget' && hasPermission('approve_requisitions')): ?>
                                    <button class="btn btn-sm btn-primary" onclick="showBudgetModal(<?php echo $req['id']; ?>)">
                                        <i class="fas fa-check-circle me-1"></i> Budget Check
                                    </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Budget Modal -->
    <div class="modal fade" id="budgetModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-coins me-2 text-primary"></i> Budget Approval</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <input type="hidden" name="requisition_id" id="req_id">
                        <div class="mb-3">
                            <label class="form-label">Action</label>
                            <select name="action" class="form-select" required>
                                <option value="approve">Approve</option>
                                <option value="reject">Reject</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Remarks</label>
                            <textarea name="remarks" class="form-control" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="approve_budget" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        let itemIndex = 1;
        
        function addItemRow() {
            const container = document.getElementById('items-container');
            const row = document.createElement('div');
            row.className = 'row g-2 item-row';
            row.innerHTML = `
                <div class="col-4">
                    <input type="text" name="items[${itemIndex}][description]" class="form-control" placeholder="Item description" required>
                </div>
                <div class="col-2">
                    <input type="number" name="items[${itemIndex}][quantity]" class="form-control" placeholder="Qty" required>
                </div>
                <div class="col-2">
                    <select name="items[${itemIndex}][unit]" class="form-select"><option value="pcs">pcs</option><option value="unit">unit</option><option value="box">box</option><option value="set">set</option><option value="pack">pack</option></select>
                </div>
                <div class="col-3">
                    <input type="number" step="0.01" name="items[${itemIndex}][estimated_price]" class="form-control" placeholder="Price" required>
                </div>
                <div class="col-1">
                    <button type="button" class="btn btn-danger btn-sm" onclick="this.closest('.item-row').remove()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            `;
            container.appendChild(row);
            itemIndex++;
        }
        
        function showBudgetModal(id) {
            document.getElementById('req_id').value = id;
            new bootstrap.Modal(document.getElementById('budgetModal')).show();
        }
    </script>
    
    <script src="<?php echo BASE_PATH; ?>assets/vendor/sweetalert2/sweetalert2.all.min.js?v=20261005"></script>
    <script src="<?php echo BASE_PATH; ?>assets/vendor/bootstrap/bootstrap.bundle.min.js?v=20261005"></script>
    <script src="<?php echo BASE_PATH; ?>assets/js/script.js?v=20261005"></script>
</body>
</html>