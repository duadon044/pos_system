/* =========================================================
   THEME MANAGER (light / dark) — saved in localStorage and applied
   to every page. The initial value is set by a tiny inline script in
   each <head> so there is no flash when a page loads.
   ========================================================= */
(function () {
  'use strict';
  var KEY = 'pos_theme';
  var root = document.documentElement;

  function current() {
    return root.getAttribute('data-pos-theme') === 'dark' ? 'dark' : 'light';
  }

  function paint(theme) {
    root.setAttribute('data-pos-theme', theme);
    root.setAttribute('data-bs-theme', theme);
    document.querySelectorAll('[data-theme-choice]').forEach(function (el) {
      var on = el.getAttribute('data-theme-choice') === theme;
      el.classList.toggle('active', on);
      el.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
    document.querySelectorAll('[data-theme-toggle]').forEach(function (el) {
      el.setAttribute('aria-label', theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode');
      el.setAttribute('title', theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode');
    });
    var meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', theme === 'dark' ? '#0b1020' : '#4f46e5');
  }

  function pulse(evt) {
    var el = document.getElementById('themeTransition');
    if (!el) { el = document.createElement('div'); el.id = 'themeTransition'; document.body.appendChild(el); }
    if (evt && typeof evt.clientX === 'number') {
      el.style.setProperty('--theme-x', evt.clientX + 'px');
      el.style.setProperty('--theme-y', evt.clientY + 'px');
    }
    el.classList.remove('run'); void el.offsetWidth; el.classList.add('run');
  }

  function setTheme(theme, evt) {
    if (theme !== 'dark' && theme !== 'light') return;
    if (theme === current() && !evt) { paint(theme); return; }
    try { localStorage.setItem(KEY, theme); } catch (e) {}
    paint(theme);
    if (evt && document.body) pulse(evt);
  }

  window.posTheme = { get: current, set: setTheme, toggle: function (e) { setTheme(current() === 'dark' ? 'light' : 'dark', e); } };

  document.addEventListener('click', function (e) {
    var choice = e.target.closest('[data-theme-choice]');
    if (choice) { setTheme(choice.getAttribute('data-theme-choice'), e); return; }
    var toggle = e.target.closest('[data-theme-toggle]');
    if (toggle) { window.posTheme.toggle(e); }
  });

  // Keep every open tab / window in sync.
  window.addEventListener('storage', function (e) {
    if (e.key === KEY && (e.newValue === 'dark' || e.newValue === 'light')) paint(e.newValue);
  });

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { paint(current()); });
  else paint(current());
})();

(function () {
  'use strict';

  const root = document.documentElement;

  function saved(key, fallback) {
    try { return localStorage.getItem(key) || fallback; } catch (e) { return fallback; }
  }

  function store(key, value) {
    try { localStorage.setItem(key, value); } catch (e) {}
  }

  function swalBase(opts){
    const primary=getComputedStyle(root).getPropertyValue('--pos-primary').trim() || '#4f46e5';
    const dark=root.getAttribute('data-pos-theme')==='dark';
    return Object.assign({
      buttonsStyling:true,
      customClass:{popup:'pos-swal',confirmButton:'pos-swal-confirm',cancelButton:'pos-swal-cancel'},
      confirmButtonColor:primary,
      background:dark?'#172033':'#ffffff',
      color:dark?'#f8fafc':'#172033'
    },opts||{});
  }

  // Small corner notification used by the POS (add to cart, item removed, ...)
  window.showToast = function (message, type, position) {
    const icon = ['success', 'error', 'warning', 'info', 'question'].includes(type) ? type : 'info';
    if (!window.Swal) { return; }
    Swal.fire(swalBase({
      toast: true, position: position || 'bottom-end', icon: icon, title: String(message),
      showConfirmButton: false, timer: 1800, timerProgressBar: true
    }));
  };

  window.showSuccess = function (message, title) {
    if (window.Swal) return Swal.fire(swalBase({icon:'success',title:title || 'Success',html:String(message)}));
    window.alert(message);
  };

  window.showError = function (message, title) {
    if (window.Swal) return Swal.fire(swalBase({icon:'error',title:title || 'Something went wrong',html:String(message)}));
    window.alert(message);
  };

  window.confirmAction = function (message, confirmText, callback, title) {
    if (!window.Swal) return window.confirm(message) && typeof callback === 'function' && callback();
    Swal.fire(swalBase({
      icon:'warning', title:title || 'Are you sure?', html:String(message),
      showCancelButton:true, confirmButtonText:confirmText || 'Continue', cancelButtonText:'Cancel',
      reverseButtons:true
    })).then(result => { if (result.isConfirmed && typeof callback === 'function') callback(); });
  };

  window.confirmDelete = function (message, callback) {
    return window.confirmAction(message || 'This action cannot be undone.', 'Delete', callback, 'Delete permanently?');
  };

  document.addEventListener('DOMContentLoaded', function () {
    root.setAttribute('data-pos-palette', 'indigo');

    const flash = document.getElementById('flash-message');
    if (flash) {
      const message = flash.dataset.message || '';
      const type = flash.dataset.type === 'success' ? 'success' : 'error';
      if (window.Swal) {
        Swal.fire(swalBase({ toast:true, position:'top-end', icon:type, title:type === 'success' ? 'Success' : 'Error', text:message, timer:2600, timerProgressBar:true, showConfirmButton:false }));
        flash.remove();
      } else {
        const alert = document.createElement('div');
        alert.className = 'alert alert-' + (type === 'success' ? 'success' : 'danger') + ' alert-dismissible fade show';
        alert.textContent = message;
        const btn = document.createElement('button');
        btn.type='button'; btn.className='btn-close'; btn.dataset.bsDismiss='alert';
        alert.appendChild(btn); flash.replaceWith(alert);
      }
    }
  });
})();

/* =========================================================
   V4.2 SIDEBAR CONTROLLER
   ========================================================= */
(function(){
  'use strict';
  function initSidebar(){
    const body=document.body;
    const toggle=document.getElementById('sidebarToggle');
    const sidebar=document.querySelector('.sidebar');
    if(!toggle || !sidebar) return;

    let backdrop=document.querySelector('.sidebar-backdrop');
    if(!backdrop){
      backdrop=document.createElement('div');
      backdrop.className='sidebar-backdrop';
      backdrop.setAttribute('aria-hidden','true');
      document.body.appendChild(backdrop);
    }

    const desktopQuery=window.matchMedia('(min-width: 992px)');
    function syncToggle(){
      const desktop=desktopQuery.matches;
      const open=desktop ? !body.classList.contains('sidebar-collapsed') : body.classList.contains('sidebar-mobile-open');
      toggle.classList.toggle('is-open',open);
      toggle.setAttribute('aria-expanded',open?'true':'false');
    }

    function closeMobile(){
      body.classList.remove('sidebar-mobile-open');
      syncToggle();
    }

    toggle.addEventListener('click',function(){
      if(desktopQuery.matches){
        body.classList.toggle('sidebar-collapsed');
        try{localStorage.setItem('pos_sidebar_collapsed',body.classList.contains('sidebar-collapsed')?'1':'0');}catch(e){}
      }else{
        body.classList.toggle('sidebar-mobile-open');
      }
      syncToggle();
    });
    backdrop.addEventListener('click',closeMobile);

    sidebar.querySelectorAll('.sidebar-section-toggle[data-sidebar-section]').forEach(function(btn){
      btn.addEventListener('click',function(){
        const id=btn.getAttribute('data-sidebar-section');
        const panel=document.getElementById(id);
        if(!panel) return;
        const open=panel.classList.toggle('is-open');
        btn.classList.toggle('is-open',open);
        btn.setAttribute('aria-expanded',open?'true':'false');
      });
    });

    sidebar.querySelectorAll('a.nav-link').forEach(function(link){
      link.addEventListener('click',function(){
        if(!desktopQuery.matches) closeMobile();
      });
    });

    try{
      if(desktopQuery.matches && localStorage.getItem('pos_sidebar_collapsed')==='1') body.classList.add('sidebar-collapsed');
    }catch(e){}

    function viewportChanged(){
      if(desktopQuery.matches) body.classList.remove('sidebar-mobile-open');
      else body.classList.remove('sidebar-collapsed');
      syncToggle();
    }
    if(desktopQuery.addEventListener) desktopQuery.addEventListener('change',viewportChanged);
    else if(desktopQuery.addListener) desktopQuery.addListener(viewportChanged);
    syncToggle();
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',initSidebar);
  else initSidebar();
})();
