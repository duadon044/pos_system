/* PayMongo-style checkout (SIMULATED UI).
 * No card or password data is sent anywhere or stored - only a generated
 * payment reference is returned. Replace the "simulate" step with a real
 * PayMongo API call (server-side, with your secret key) for live payments. */
(function () {
  var esc = function (s) { return String(s).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); };
  var peso = function (n) { return '₱' + Number(n).toLocaleString('en-PH', {minimumFractionDigits: 2, maximumFractionDigits: 2}); };
  function makeRef() {
    var a = new Uint32Array(2); (window.crypto || window.msCrypto).getRandomValues(a);
    var d = new Date(), p = function (n) { return String(n).padStart(2, '0'); };
    return 'PMG-' + d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + '-' + (a[0].toString(36) + a[1].toString(36)).toUpperCase().slice(0, 6);
  }
  function luhn(num) {
    var s = 0, alt = false;
    for (var i = num.length - 1; i >= 0; i--) { var n = +num[i]; if (alt) { n *= 2; if (n > 9) n -= 9; } s += n; alt = !alt; }
    return num.length >= 13 && s % 10 === 0;
  }
  function brand(num) {
    if (/^4/.test(num)) return 'Visa';
    if (/^(5[1-5]|2[2-7])/.test(num)) return 'Mastercard';
    if (/^3[47]/.test(num)) return 'Amex';
    if (/^35/.test(num)) return 'JCB';
    return 'Card';
  }

  function open(opts) {
    opts = opts || {};
    var amount = Number(opts.amount) || 0;
    return new Promise(function (resolve) {
      var done = false, result = null;
      var el = document.createElement('div');
      el.className = 'modal fade pmg-modal';
      el.tabIndex = -1;
      el.innerHTML =
        '<div class="modal-dialog modal-dialog-centered"><div class="modal-content">' +
        '<div class="pmg-head"><button type="button" class="pmg-close" data-pmg="close" aria-label="Close">&times;</button>' +
        '<div class="pmg-brand"><span class="pmg-logo">P</span>PayMongo<span class="pmg-test">TEST MODE</span></div>' +
        '<div class="pmg-amount-label">Amount to pay</div><div class="pmg-amount">' + peso(amount) + '</div>' +
        '<div class="pmg-desc">' + esc(opts.description || 'Payment') + '</div></div>' +
        '<div class="pmg-body" id="pmgBody"></div></div></div>';
      document.body.appendChild(el);
      var modal = new bootstrap.Modal(el, {backdrop: 'static', keyboard: false});
      var body = el.querySelector('#pmgBody');
      var tab = 'account';

      function secure() { return '<div class="pmg-secure"><i class="fas fa-lock"></i> Secured by PayMongo &middot; simulated checkout</div>'; }

      function render() {
        body.innerHTML =
          '<div class="pmg-tabs"><button class="pmg-tab' + (tab === 'account' ? ' active' : '') + '" data-tab="account"><i class="fas fa-user me-1"></i>Log in</button>' +
          '<button class="pmg-tab' + (tab === 'card' ? ' active' : '') + '" data-tab="card"><i class="far fa-credit-card me-1"></i>Card</button></div>' +
          '<div id="pmgPane"></div>' + secure();
        body.querySelectorAll('.pmg-tab').forEach(function (b) { b.onclick = function () { tab = b.dataset.tab; render(); }; });
        (tab === 'account' ? accountPane : cardPane)(body.querySelector('#pmgPane'));
      }

      function accountPane(p) {
        p.innerHTML =
          '<div class="pmg-field"><label class="pmg-label">Email or mobile number</label><input class="pmg-input" id="pmgEmail" autocomplete="username" placeholder="you@example.com"></div>' +
          '<div class="pmg-field"><label class="pmg-label">Password</label><div class="pmg-pw"><input class="pmg-input" id="pmgPass" type="password" autocomplete="current-password" placeholder="Enter your password"><button type="button" id="pmgShow">Show</button></div></div>' +
          '<div class="pmg-err" id="pmgErr"></div>' +
          '<button class="pmg-btn" id="pmgLogin">Log in &amp; continue</button>' +
          '<button class="pmg-link" data-pmg="card">Pay with card instead</button>';
        var pw = p.querySelector('#pmgPass');
        p.querySelector('#pmgShow').onclick = function () { pw.type = pw.type === 'password' ? 'text' : 'password'; this.textContent = pw.type === 'password' ? 'Show' : 'Hide'; };
        p.querySelector('[data-pmg="card"]').onclick = function () { tab = 'card'; render(); };
        var go = function () {
          var u = p.querySelector('#pmgEmail'), err = p.querySelector('#pmgErr');
          var v = u.value.trim();
          var ok = /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v) || /^(\+?63|0)9\d{9}$/.test(v.replace(/[\s-]/g, ''));
          u.classList.toggle('pmg-bad', !ok); pw.classList.toggle('pmg-bad', pw.value.length < 6);
          if (!ok) { err.textContent = 'Enter a valid email or mobile number.'; return; }
          if (pw.value.length < 6) { err.textContent = 'Password must be at least 6 characters.'; return; }
          var btn = p.querySelector('#pmgLogin'); btn.disabled = true; btn.innerHTML = '<span class="pmg-spin"></span>Logging in...';
          setTimeout(function () { confirmPane(v); }, 700);
        };
        p.querySelector('#pmgLogin').onclick = go;
        p.addEventListener('keydown', function (e) { if (e.key === 'Enter') go(); });
        setTimeout(function () { p.querySelector('#pmgEmail').focus(); }, 250);
      }

      function confirmPane(user) {
        body.innerHTML =
          '<div class="pmg-user"><div class="pmg-avatar">' + esc(user.charAt(0).toUpperCase()) + '</div><div><strong>' + esc(user) + '</strong><small>PayMongo account</small></div></div>' +
          '<div class="d-flex justify-content-between mb-3"><span class="text-muted">Total</span><strong>' + peso(amount) + '</strong></div>' +
          '<button class="pmg-btn" id="pmgPay">Pay ' + peso(amount) + '</button>' +
          '<button class="pmg-link" id="pmgSwitch">Use a different account</button>' + secure();
        body.querySelector('#pmgSwitch').onclick = function () { tab = 'account'; render(); };
        body.querySelector('#pmgPay').onclick = function () { pay(this, 'account'); };
      }

      function cardPane(p) {
        p.innerHTML =
          '<div class="pmg-card-icons"><span class="pmg-chip">VISA</span><span class="pmg-chip">MASTERCARD</span><span class="pmg-chip">JCB</span></div>' +
          '<div class="pmg-field"><label class="pmg-label">Card number</label><input class="pmg-input" id="pmgNum" inputmode="numeric" autocomplete="off" placeholder="1234 5678 9012 3456" maxlength="23"></div>' +
          '<div class="pmg-row"><div class="pmg-field"><label class="pmg-label">Expiry</label><input class="pmg-input" id="pmgExp" inputmode="numeric" autocomplete="off" placeholder="MM / YY" maxlength="7"></div>' +
          '<div class="pmg-field"><label class="pmg-label">CVC</label><input class="pmg-input" id="pmgCvc" inputmode="numeric" type="password" autocomplete="off" placeholder="123" maxlength="4"></div></div>' +
          '<div class="pmg-field"><label class="pmg-label">Name on card</label><input class="pmg-input" id="pmgName" autocomplete="off" placeholder="Juan Dela Cruz"></div>' +
          '<div class="pmg-err" id="pmgErr"></div><button class="pmg-btn" id="pmgPay">Pay ' + peso(amount) + '</button>' +
          '<button class="pmg-link" data-pmg="acct">Log in to your PayMongo account instead</button>';
        var num = p.querySelector('#pmgNum'), exp = p.querySelector('#pmgExp'), cvc = p.querySelector('#pmgCvc');
        num.oninput = function () { var d = num.value.replace(/\D/g, '').slice(0, 19); num.value = d.replace(/(.{4})/g, '$1 ').trim(); };
        exp.oninput = function () { var d = exp.value.replace(/\D/g, '').slice(0, 4); exp.value = d.length > 2 ? d.slice(0, 2) + ' / ' + d.slice(2) : d; };
        cvc.oninput = function () { cvc.value = cvc.value.replace(/\D/g, '').slice(0, 4); };
        p.querySelector('[data-pmg="acct"]').onclick = function () { tab = 'account'; render(); };
        p.querySelector('#pmgPay').onclick = function () {
          var n = num.value.replace(/\D/g, ''), m = exp.value.replace(/\D/g, ''), err = p.querySelector('#pmgErr');
          var mm = +m.slice(0, 2), yy = 2000 + +m.slice(2, 4), now = new Date();
          var okN = luhn(n), okE = m.length === 4 && mm >= 1 && mm <= 12 && (yy > now.getFullYear() || (yy === now.getFullYear() && mm >= now.getMonth() + 1));
          var okC = cvc.value.length >= 3, okName = p.querySelector('#pmgName').value.trim().length >= 2;
          num.classList.toggle('pmg-bad', !okN); exp.classList.toggle('pmg-bad', !okE); cvc.classList.toggle('pmg-bad', !okC); p.querySelector('#pmgName').classList.toggle('pmg-bad', !okName);
          if (!okN) { err.textContent = 'Enter a valid card number.'; return; }
          if (!okE) { err.textContent = 'Enter a valid, unexpired date.'; return; }
          if (!okC) { err.textContent = 'Enter the 3 or 4 digit CVC.'; return; }
          if (!okName) { err.textContent = 'Enter the name on the card.'; return; }
          pay(this, brand(n));
        };
      }

      function pay(btn, via) {
        btn.disabled = true; btn.innerHTML = '<span class="pmg-spin"></span>Processing...';
        setTimeout(function () {
          var ref = makeRef(); result = {reference: ref, via: via, amount: amount};
          body.innerHTML = '<div class="pmg-done"><div class="pmg-check"><i class="fas fa-check"></i></div><h5 class="mb-1">Payment successful</h5>' +
            '<div class="text-muted">' + peso(amount) + ' paid</div><div class="pmg-ref">' + ref + '</div></div>' +
            '<button class="pmg-btn mt-3" id="pmgDone">Continue</button>';
          body.querySelector('#pmgDone').onclick = function () { done = true; modal.hide(); };
        }, 1200);
      }

      el.addEventListener('click', function (e) { if (e.target.closest('[data-pmg="close"]')) modal.hide(); });
      el.addEventListener('hidden.bs.modal', function () { el.remove(); resolve(done ? result : null); });
      render(); modal.show();
    });
  }
  window.PayMongoCheckout = {open: open};
})();
